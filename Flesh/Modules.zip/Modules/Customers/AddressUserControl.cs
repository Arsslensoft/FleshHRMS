﻿using System;
using System.Collections.Generic;
using System.Linq;
using DevExpress.XtraEditors;
using DevExpress.Utils.Controls;

namespace FHRMS.Modules.Customers {
    public partial class AddressUserControl : XtraUserControl, IXtraResizableControl {
        public AddressUserControl() {
            InitializeComponent();
        }
    }
}

﻿namespace FHRMS.Modules {
    partial class ModifierCongés {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if(disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject1 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject2 = new DevExpress.Utils.SerializableAppearanceObject();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ModifierCongés));
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject3 = new DevExpress.Utils.SerializableAppearanceObject();
            this.layout = new DevExpress.XtraDataLayout.DataLayoutControl();
            this.fullNameLabelControl = new DevExpress.XtraEditors.LabelControl();
            this.taskBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.cancelSimpleButton = new DevExpress.XtraEditors.SimpleButton();
            this.saveSimpleButton = new DevExpress.XtraEditors.SimpleButton();
            this.cbReminderDate = new DevExpress.XtraEditors.DateEdit();
            this.cbReminder = new DevExpress.XtraEditors.CheckEdit();
            this.descriptionMemoEdit = new DevExpress.XtraEditors.MemoEdit();
            this.subjectMemoEdit = new DevExpress.XtraEditors.MemoEdit();
            this.dueDateEdit = new DevExpress.XtraEditors.DateEdit();
            this.startDateEdit = new DevExpress.XtraEditors.DateEdit();
            this.linkedToLookUpEdit = new DevExpress.XtraEditors.ImageComboBoxEdit();
            this.assignedToLookUpEdit = new DevExpress.XtraEditors.LookUpEdit();
            this.ownerLookUpEdit = new DevExpress.XtraEditors.LookUpEdit();
            this.statusImageComboBoxEdit = new DevExpress.XtraEditors.ImageComboBoxEdit();
            this.statusImageList = new DevExpress.Utils.ImageCollection(this.components);
            this.priorityImageComboBoxEdit = new DevExpress.XtraEditors.ImageComboBoxEdit();
            this.priorityImageList = new DevExpress.Utils.ImageCollection(this.components);
            this.cbReminderTime = new DevExpress.XtraEditors.TimeEdit();
            this.layoutControlGroup1 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem2 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem4 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem5 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem6 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem7 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem8 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem9 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem11 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem12 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem13 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem3 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem15 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem16 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem17 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem18 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem10 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem1 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem4 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem2 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem1 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem5 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem6 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem7 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem8 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem9 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem3 = new DevExpress.XtraLayout.LayoutControlItem();
            ((System.ComponentModel.ISupportInitialize)(this.layout)).BeginInit();
            this.layout.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.taskBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbReminderDate.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbReminderDate.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbReminder.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.descriptionMemoEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.subjectMemoEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dueDateEdit.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dueDateEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.startDateEdit.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.startDateEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.linkedToLookUpEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.assignedToLookUpEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ownerLookUpEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.statusImageComboBoxEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.statusImageList)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.priorityImageComboBoxEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.priorityImageList)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbReminderTime.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).BeginInit();
            this.SuspendLayout();
            // 
            // layout
            // 
            this.layout.AllowCustomization = false;
            this.layout.Controls.Add(this.fullNameLabelControl);
            this.layout.Controls.Add(this.labelControl1);
            this.layout.Controls.Add(this.cancelSimpleButton);
            this.layout.Controls.Add(this.saveSimpleButton);
            this.layout.Controls.Add(this.cbReminderDate);
            this.layout.Controls.Add(this.cbReminder);
            this.layout.Controls.Add(this.descriptionMemoEdit);
            this.layout.Controls.Add(this.subjectMemoEdit);
            this.layout.Controls.Add(this.dueDateEdit);
            this.layout.Controls.Add(this.startDateEdit);
            this.layout.Controls.Add(this.linkedToLookUpEdit);
            this.layout.Controls.Add(this.assignedToLookUpEdit);
            this.layout.Controls.Add(this.ownerLookUpEdit);
            this.layout.Controls.Add(this.statusImageComboBoxEdit);
            this.layout.Controls.Add(this.priorityImageComboBoxEdit);
            this.layout.Controls.Add(this.cbReminderTime);
            this.layout.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layout.Location = new System.Drawing.Point(0, 0);
            this.layout.Name = "layout";
            this.layout.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new System.Drawing.Rectangle(993, 840, 781, 781);
            this.layout.Root = this.layoutControlGroup1;
            this.layout.Size = new System.Drawing.Size(1002, 531);
            this.layout.TabIndex = 0;
            this.layout.Text = "layoutControl1";
            // 
            // fullNameLabelControl
            // 
            this.fullNameLabelControl.AllowHtmlString = true;
            this.fullNameLabelControl.Appearance.FontSizeDelta = 3;
            this.fullNameLabelControl.Appearance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(140)))), ((int)(((byte)(140)))));
            this.fullNameLabelControl.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.taskBindingSource, "Subject", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.fullNameLabelControl.Location = new System.Drawing.Point(145, 20);
            this.fullNameLabelControl.Name = "fullNameLabelControl";
            this.fullNameLabelControl.Size = new System.Drawing.Size(845, 25);
            this.fullNameLabelControl.StyleController = this.layout;
            this.fullNameLabelControl.TabIndex = 20;
            this.fullNameLabelControl.Text = "%USERNAME";
            // 
            // taskBindingSource
            // 
            this.taskBindingSource.DataSource = typeof(FHRMS.Data.Leave);
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.FontSizeDelta = 3;
            this.labelControl1.Location = new System.Drawing.Point(12, 20);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(129, 25);
            this.labelControl1.StyleController = this.layout;
            this.labelControl1.TabIndex = 19;
            this.labelControl1.Text = "Modifier congé";
            // 
            // cancelSimpleButton
            // 
            this.cancelSimpleButton.Appearance.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancelSimpleButton.Appearance.Options.UseFont = true;
            this.cancelSimpleButton.Location = new System.Drawing.Point(889, 447);
            this.cancelSimpleButton.MaximumSize = new System.Drawing.Size(101, 35);
            this.cancelSimpleButton.MinimumSize = new System.Drawing.Size(101, 35);
            this.cancelSimpleButton.Name = "cancelSimpleButton";
            this.cancelSimpleButton.Size = new System.Drawing.Size(101, 35);
            this.cancelSimpleButton.StyleController = this.layout;
            this.cancelSimpleButton.TabIndex = 18;
            this.cancelSimpleButton.Text = "Annuler";
            // 
            // saveSimpleButton
            // 
            this.saveSimpleButton.Appearance.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saveSimpleButton.Appearance.Options.UseFont = true;
            this.saveSimpleButton.Location = new System.Drawing.Point(770, 447);
            this.saveSimpleButton.MaximumSize = new System.Drawing.Size(101, 35);
            this.saveSimpleButton.MinimumSize = new System.Drawing.Size(101, 35);
            this.saveSimpleButton.Name = "saveSimpleButton";
            this.saveSimpleButton.Size = new System.Drawing.Size(101, 35);
            this.saveSimpleButton.StyleController = this.layout;
            this.saveSimpleButton.TabIndex = 17;
            this.saveSimpleButton.Text = "Enregistrer";
            // 
            // cbReminderDate
            // 
            this.cbReminderDate.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.taskBindingSource, "ReminderDateTime", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.cbReminderDate.EditValue = null;
            this.cbReminderDate.Location = new System.Drawing.Point(542, 391);
            this.cbReminderDate.Name = "cbReminderDate";
            this.cbReminderDate.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Glyph, "", -1, true, true, false, DevExpress.XtraEditors.ImageLocation.MiddleCenter, global::FHRMS.Properties.Resources.DateEditIcon, new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject1, "", null, null, true)});
            this.cbReminderDate.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cbReminderDate.Properties.CalendarView = DevExpress.XtraEditors.Repository.CalendarView.TouchUI;
            this.cbReminderDate.Properties.MinValue = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.cbReminderDate.Properties.VistaDisplayMode = DevExpress.Utils.DefaultBoolean.False;
            this.cbReminderDate.Size = new System.Drawing.Size(127, 42);
            this.cbReminderDate.StyleController = this.layout;
            this.cbReminderDate.TabIndex = 14;
            // 
            // cbReminder
            // 
            this.cbReminder.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.taskBindingSource, "Reminder", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.cbReminder.EditValue = true;
            this.cbReminder.Location = new System.Drawing.Point(500, 400);
            this.cbReminder.Margin = new System.Windows.Forms.Padding(0);
            this.cbReminder.Name = "cbReminder";
            this.cbReminder.Properties.Caption = "";
            this.cbReminder.Size = new System.Drawing.Size(38, 24);
            this.cbReminder.StyleController = this.layout;
            this.cbReminder.TabIndex = 13;
            this.cbReminder.CheckedChanged += new System.EventHandler(this.cbReminder_CheckedChanged);
            // 
            // descriptionMemoEdit
            // 
            this.descriptionMemoEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.taskBindingSource, "Subject", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.descriptionMemoEdit.Location = new System.Drawing.Point(500, 67);
            this.descriptionMemoEdit.Name = "descriptionMemoEdit";
            this.descriptionMemoEdit.Properties.NullValuePrompt = "Enter Subject";
            this.descriptionMemoEdit.Properties.NullValuePromptShowForEmptyValue = true;
            this.descriptionMemoEdit.Size = new System.Drawing.Size(490, 84);
            this.descriptionMemoEdit.StyleController = this.layout;
            this.descriptionMemoEdit.TabIndex = 12;
            // 
            // subjectMemoEdit
            // 
            this.subjectMemoEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.taskBindingSource, "Description", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.subjectMemoEdit.Location = new System.Drawing.Point(500, 155);
            this.subjectMemoEdit.Name = "subjectMemoEdit";
            this.subjectMemoEdit.Properties.NullValuePrompt = "Enter Description";
            this.subjectMemoEdit.Properties.NullValuePromptShowForEmptyValue = true;
            this.subjectMemoEdit.Size = new System.Drawing.Size(490, 208);
            this.subjectMemoEdit.StyleController = this.layout;
            this.subjectMemoEdit.TabIndex = 11;
            // 
            // dueDateEdit
            // 
            this.dueDateEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.taskBindingSource, "DueDate", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.dueDateEdit.EditValue = null;
            this.dueDateEdit.Location = new System.Drawing.Point(123, 275);
            this.dueDateEdit.Name = "dueDateEdit";
            this.dueDateEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Glyph, "", -1, true, true, false, DevExpress.XtraEditors.ImageLocation.MiddleCenter, global::FHRMS.Properties.Resources.DateEditIcon, new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject2, "", null, null, true)});
            this.dueDateEdit.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dueDateEdit.Properties.CalendarView = DevExpress.XtraEditors.Repository.CalendarView.TouchUI;
            this.dueDateEdit.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.None;
            this.dueDateEdit.Properties.MinValue = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.dueDateEdit.Properties.VistaDisplayMode = DevExpress.Utils.DefaultBoolean.False;
            this.dueDateEdit.Size = new System.Drawing.Size(206, 42);
            this.dueDateEdit.StyleController = this.layout;
            this.dueDateEdit.TabIndex = 8;
            // 
            // startDateEdit
            // 
            this.startDateEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.taskBindingSource, "StartDate", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.startDateEdit.EditValue = null;
            this.startDateEdit.Location = new System.Drawing.Point(123, 229);
            this.startDateEdit.Name = "startDateEdit";
            this.startDateEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Glyph, "", -1, true, true, false, DevExpress.XtraEditors.ImageLocation.MiddleCenter, ((System.Drawing.Image)(resources.GetObject("startDateEdit.Properties.Buttons"))), new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject3, "", null, null, true)});
            this.startDateEdit.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.startDateEdit.Properties.CalendarView = DevExpress.XtraEditors.Repository.CalendarView.TouchUI;
            this.startDateEdit.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.None;
            this.startDateEdit.Properties.MinValue = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.startDateEdit.Properties.VistaDisplayMode = DevExpress.Utils.DefaultBoolean.False;
            this.startDateEdit.Size = new System.Drawing.Size(206, 42);
            this.startDateEdit.StyleController = this.layout;
            this.startDateEdit.TabIndex = 7;
            // 
            // linkedToLookUpEdit
            // 
            this.linkedToLookUpEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.taskBindingSource, "Kind", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.linkedToLookUpEdit.Location = new System.Drawing.Point(123, 159);
            this.linkedToLookUpEdit.Name = "linkedToLookUpEdit";
            this.linkedToLookUpEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.linkedToLookUpEdit.Size = new System.Drawing.Size(206, 42);
            this.linkedToLookUpEdit.StyleController = this.layout;
            this.linkedToLookUpEdit.TabIndex = 6;
            // 
            // assignedToLookUpEdit
            // 
            this.assignedToLookUpEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.taskBindingSource, "AssignedEmployee", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.assignedToLookUpEdit.EditValue = "<Null>";
            this.assignedToLookUpEdit.Location = new System.Drawing.Point(123, 113);
            this.assignedToLookUpEdit.Name = "assignedToLookUpEdit";
            this.assignedToLookUpEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.assignedToLookUpEdit.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("FullNameBindable", "FullName")});
            this.assignedToLookUpEdit.Properties.DisplayMember = "FullNameBindable";
            this.assignedToLookUpEdit.Properties.NullText = "";
            this.assignedToLookUpEdit.Properties.ShowHeader = false;
            this.assignedToLookUpEdit.Size = new System.Drawing.Size(206, 42);
            this.assignedToLookUpEdit.StyleController = this.layout;
            this.assignedToLookUpEdit.TabIndex = 5;
            // 
            // ownerLookUpEdit
            // 
            this.ownerLookUpEdit.AllowHtmlTextInToolTip = DevExpress.Utils.DefaultBoolean.False;
            this.ownerLookUpEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.taskBindingSource, "Owner", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.ownerLookUpEdit.EditValue = "<Null>";
            this.ownerLookUpEdit.Location = new System.Drawing.Point(123, 67);
            this.ownerLookUpEdit.Name = "ownerLookUpEdit";
            this.ownerLookUpEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.ownerLookUpEdit.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("FullNameBindable", "FullName")});
            this.ownerLookUpEdit.Properties.DisplayMember = "FullNameBindable";
            this.ownerLookUpEdit.Properties.NullText = "";
            this.ownerLookUpEdit.Properties.ShowHeader = false;
            this.ownerLookUpEdit.Size = new System.Drawing.Size(206, 42);
            this.ownerLookUpEdit.StyleController = this.layout;
            this.ownerLookUpEdit.TabIndex = 4;
            // 
            // statusImageComboBoxEdit
            // 
            this.statusImageComboBoxEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.taskBindingSource, "Status", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.statusImageComboBoxEdit.EditValue = "<Null>";
            this.statusImageComboBoxEdit.Location = new System.Drawing.Point(123, 345);
            this.statusImageComboBoxEdit.Name = "statusImageComboBoxEdit";
            this.statusImageComboBoxEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.statusImageComboBoxEdit.Properties.LargeImages = this.statusImageList;
            this.statusImageComboBoxEdit.Properties.PopupSizeable = true;
            this.statusImageComboBoxEdit.Properties.SmallImages = this.statusImageList;
            this.statusImageComboBoxEdit.Properties.Sorted = true;
            this.statusImageComboBoxEdit.Size = new System.Drawing.Size(206, 42);
            this.statusImageComboBoxEdit.StyleController = this.layout;
            this.statusImageComboBoxEdit.TabIndex = 9;
            // 
            // statusImageList
            // 
            this.statusImageList.ImageSize = new System.Drawing.Size(24, 24);
            this.statusImageList.ImageStream = ((DevExpress.Utils.ImageCollectionStreamer)(resources.GetObject("statusImageList.ImageStream")));
            this.statusImageList.Images.SetKeyName(0, "NotStarted.png");
            this.statusImageList.Images.SetKeyName(1, "InProgress.png");
            this.statusImageList.InsertImage(global::FHRMS.Properties.Resources.Clear, "Clear", typeof(global::FHRMS.Properties.Resources), 2);
            this.statusImageList.Images.SetKeyName(2, "Clear");
            this.statusImageList.Images.SetKeyName(3, "Completed.png");
            // 
            // priorityImageComboBoxEdit
            // 
            this.priorityImageComboBoxEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.taskBindingSource, "Priority", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.priorityImageComboBoxEdit.EditValue = "<Null>";
            this.priorityImageComboBoxEdit.Location = new System.Drawing.Point(123, 391);
            this.priorityImageComboBoxEdit.Name = "priorityImageComboBoxEdit";
            this.priorityImageComboBoxEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.priorityImageComboBoxEdit.Properties.LargeImages = this.priorityImageList;
            this.priorityImageComboBoxEdit.Properties.PopupSizeable = true;
            this.priorityImageComboBoxEdit.Properties.SmallImages = this.priorityImageList;
            this.priorityImageComboBoxEdit.Size = new System.Drawing.Size(206, 42);
            this.priorityImageComboBoxEdit.StyleController = this.layout;
            this.priorityImageComboBoxEdit.TabIndex = 10;
            // 
            // priorityImageList
            // 
            this.priorityImageList.ImageSize = new System.Drawing.Size(24, 24);
            this.priorityImageList.ImageStream = ((DevExpress.Utils.ImageCollectionStreamer)(resources.GetObject("priorityImageList.ImageStream")));
            this.priorityImageList.InsertImage(global::FHRMS.Properties.Resources.LowPriority, "LowPriority", typeof(global::FHRMS.Properties.Resources), 0);
            this.priorityImageList.Images.SetKeyName(0, "LowPriority");
            this.priorityImageList.InsertImage(global::FHRMS.Properties.Resources.NormalPriority, "NormalPriority", typeof(global::FHRMS.Properties.Resources), 1);
            this.priorityImageList.Images.SetKeyName(1, "NormalPriority");
            this.priorityImageList.InsertImage(global::FHRMS.Properties.Resources.MediumPriority, "MediumPriority", typeof(global::FHRMS.Properties.Resources), 2);
            this.priorityImageList.Images.SetKeyName(2, "MediumPriority");
            this.priorityImageList.InsertImage(global::FHRMS.Properties.Resources.HighPriority, "HighPriority", typeof(global::FHRMS.Properties.Resources), 3);
            this.priorityImageList.Images.SetKeyName(3, "HighPriority");
            // 
            // cbReminderTime
            // 
            this.cbReminderTime.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.taskBindingSource, "ReminderDateTime", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.cbReminderTime.EditValue = null;
            this.cbReminderTime.Location = new System.Drawing.Point(673, 391);
            this.cbReminderTime.Name = "cbReminderTime";
            this.cbReminderTime.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cbReminderTime.Properties.EditValueChangedFiringMode = DevExpress.XtraEditors.Controls.EditValueChangedFiringMode.Default;
            this.cbReminderTime.Properties.Mask.EditMask = "t";
            this.cbReminderTime.Properties.SpinStyle = DevExpress.XtraEditors.Controls.SpinStyles.Horizontal;
            this.cbReminderTime.Size = new System.Drawing.Size(317, 42);
            this.cbReminderTime.StyleController = this.layout;
            this.cbReminderTime.TabIndex = 15;
            // 
            // layoutControlGroup1
            // 
            this.layoutControlGroup1.AppearanceItemCaption.FontSizeDelta = -1;
            this.layoutControlGroup1.AppearanceItemCaption.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(140)))), ((int)(((byte)(140)))));
            this.layoutControlGroup1.AppearanceItemCaption.Options.UseFont = true;
            this.layoutControlGroup1.AppearanceItemCaption.Options.UseForeColor = true;
            this.layoutControlGroup1.CustomizationFormText = "Root";
            this.layoutControlGroup1.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.layoutControlGroup1.GroupBordersVisible = false;
            this.layoutControlGroup1.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem2,
            this.layoutControlItem4,
            this.layoutControlItem5,
            this.layoutControlItem6,
            this.layoutControlItem7,
            this.layoutControlItem8,
            this.layoutControlItem9,
            this.layoutControlItem11,
            this.layoutControlItem12,
            this.layoutControlItem13,
            this.emptySpaceItem3,
            this.layoutControlItem15,
            this.layoutControlItem16,
            this.layoutControlItem17,
            this.layoutControlItem18,
            this.layoutControlItem10,
            this.layoutControlItem1,
            this.emptySpaceItem4,
            this.emptySpaceItem2,
            this.emptySpaceItem1,
            this.emptySpaceItem5,
            this.emptySpaceItem6,
            this.emptySpaceItem7,
            this.emptySpaceItem8,
            this.emptySpaceItem9});
            this.layoutControlGroup1.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup1.Name = "Root";
            this.layoutControlGroup1.OptionsItemText.TextToControlDistance = 24;
            this.layoutControlGroup1.Size = new System.Drawing.Size(1002, 531);
            this.layoutControlGroup1.TextVisible = false;
            // 
            // layoutControlItem2
            // 
            this.layoutControlItem2.Control = this.assignedToLookUpEdit;
            this.layoutControlItem2.CustomizationFormText = "ASSIGNED TO";
            this.layoutControlItem2.Location = new System.Drawing.Point(0, 101);
            this.layoutControlItem2.Name = "layoutControlItem2";
            this.layoutControlItem2.Size = new System.Drawing.Size(321, 46);
            this.layoutControlItem2.Text = "Employé";
            this.layoutControlItem2.TextSize = new System.Drawing.Size(87, 17);
            // 
            // layoutControlItem4
            // 
            this.layoutControlItem4.Control = this.linkedToLookUpEdit;
            this.layoutControlItem4.CustomizationFormText = "LINKED TO";
            this.layoutControlItem4.Location = new System.Drawing.Point(0, 147);
            this.layoutControlItem4.Name = "layoutControlItem4";
            this.layoutControlItem4.Size = new System.Drawing.Size(321, 46);
            this.layoutControlItem4.Text = "Type de congé";
            this.layoutControlItem4.TextSize = new System.Drawing.Size(87, 17);
            // 
            // layoutControlItem5
            // 
            this.layoutControlItem5.Control = this.startDateEdit;
            this.layoutControlItem5.CustomizationFormText = "START DATE";
            this.layoutControlItem5.Location = new System.Drawing.Point(0, 217);
            this.layoutControlItem5.Name = "layoutControlItem5";
            this.layoutControlItem5.Size = new System.Drawing.Size(321, 46);
            this.layoutControlItem5.Text = "DATE DÉBUT";
            this.layoutControlItem5.TextSize = new System.Drawing.Size(87, 17);
            // 
            // layoutControlItem6
            // 
            this.layoutControlItem6.Control = this.dueDateEdit;
            this.layoutControlItem6.CustomizationFormText = "DUE DATE";
            this.layoutControlItem6.Location = new System.Drawing.Point(0, 263);
            this.layoutControlItem6.Name = "layoutControlItem6";
            this.layoutControlItem6.Size = new System.Drawing.Size(321, 46);
            this.layoutControlItem6.Text = "DATE FIN";
            this.layoutControlItem6.TextSize = new System.Drawing.Size(87, 17);
            // 
            // layoutControlItem7
            // 
            this.layoutControlItem7.Control = this.statusImageComboBoxEdit;
            this.layoutControlItem7.CustomizationFormText = "STATUS";
            this.layoutControlItem7.Location = new System.Drawing.Point(0, 333);
            this.layoutControlItem7.Name = "layoutControlItem7";
            this.layoutControlItem7.Size = new System.Drawing.Size(321, 46);
            this.layoutControlItem7.Text = "STATUS";
            this.layoutControlItem7.TextSize = new System.Drawing.Size(87, 17);
            // 
            // layoutControlItem8
            // 
            this.layoutControlItem8.Control = this.priorityImageComboBoxEdit;
            this.layoutControlItem8.CustomizationFormText = "PRIORITY";
            this.layoutControlItem8.Location = new System.Drawing.Point(0, 379);
            this.layoutControlItem8.Name = "layoutControlItem8";
            this.layoutControlItem8.Size = new System.Drawing.Size(321, 46);
            this.layoutControlItem8.Text = "PRIORITÉ";
            this.layoutControlItem8.TextSize = new System.Drawing.Size(87, 17);
            // 
            // layoutControlItem9
            // 
            this.layoutControlItem9.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem9.AppearanceItemCaption.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.layoutControlItem9.Control = this.subjectMemoEdit;
            this.layoutControlItem9.CustomizationFormText = "DESCRIPTION";
            this.layoutControlItem9.Location = new System.Drawing.Point(377, 143);
            this.layoutControlItem9.MinSize = new System.Drawing.Size(85, 20);
            this.layoutControlItem9.Name = "layoutControlItem9";
            this.layoutControlItem9.Size = new System.Drawing.Size(605, 212);
            this.layoutControlItem9.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem9.Text = "DESCRIPTION";
            this.layoutControlItem9.TextSize = new System.Drawing.Size(87, 17);
            // 
            // layoutControlItem11
            // 
            this.layoutControlItem11.Control = this.cbReminder;
            this.layoutControlItem11.ControlAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.layoutControlItem11.CustomizationFormText = "REMINDER";
            this.layoutControlItem11.Location = new System.Drawing.Point(377, 379);
            this.layoutControlItem11.Name = "layoutControlItem11";
            this.layoutControlItem11.Size = new System.Drawing.Size(153, 46);
            this.layoutControlItem11.Text = "REMINDER";
            this.layoutControlItem11.TextSize = new System.Drawing.Size(87, 17);
            this.layoutControlItem11.TrimClientAreaToControl = false;
            // 
            // layoutControlItem12
            // 
            this.layoutControlItem12.Control = this.cbReminderDate;
            this.layoutControlItem12.CustomizationFormText = "layoutControlItem12";
            this.layoutControlItem12.Location = new System.Drawing.Point(530, 379);
            this.layoutControlItem12.Name = "layoutControlItem12";
            this.layoutControlItem12.Size = new System.Drawing.Size(131, 46);
            this.layoutControlItem12.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem12.TextVisible = false;
            // 
            // layoutControlItem13
            // 
            this.layoutControlItem13.Control = this.cbReminderTime;
            this.layoutControlItem13.CustomizationFormText = "layoutControlItem13";
            this.layoutControlItem13.Location = new System.Drawing.Point(661, 379);
            this.layoutControlItem13.Name = "layoutControlItem13";
            this.layoutControlItem13.Size = new System.Drawing.Size(321, 46);
            this.layoutControlItem13.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem13.TextVisible = false;
            // 
            // emptySpaceItem3
            // 
            this.emptySpaceItem3.AllowHotTrack = false;
            this.emptySpaceItem3.CustomizationFormText = "emptySpaceItem3";
            this.emptySpaceItem3.Location = new System.Drawing.Point(0, 435);
            this.emptySpaceItem3.Name = "emptySpaceItem3";
            this.emptySpaceItem3.Size = new System.Drawing.Size(758, 46);
            this.emptySpaceItem3.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem15
            // 
            this.layoutControlItem15.Control = this.saveSimpleButton;
            this.layoutControlItem15.CustomizationFormText = "layoutControlItem15";
            this.layoutControlItem15.Location = new System.Drawing.Point(758, 435);
            this.layoutControlItem15.Name = "layoutControlItem15";
            this.layoutControlItem15.OptionsPrint.AllowPrint = false;
            this.layoutControlItem15.Size = new System.Drawing.Size(107, 46);
            this.layoutControlItem15.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem15.TextVisible = false;
            // 
            // layoutControlItem16
            // 
            this.layoutControlItem16.Control = this.cancelSimpleButton;
            this.layoutControlItem16.CustomizationFormText = "layoutControlItem16";
            this.layoutControlItem16.Location = new System.Drawing.Point(877, 435);
            this.layoutControlItem16.Name = "layoutControlItem16";
            this.layoutControlItem16.OptionsPrint.AllowPrint = false;
            this.layoutControlItem16.Size = new System.Drawing.Size(105, 46);
            this.layoutControlItem16.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem16.TextVisible = false;
            // 
            // layoutControlItem17
            // 
            this.layoutControlItem17.Control = this.labelControl1;
            this.layoutControlItem17.CustomizationFormText = "layoutControlItem17";
            this.layoutControlItem17.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem17.Name = "layoutControlItem17";
            this.layoutControlItem17.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 2, 10, 10);
            this.layoutControlItem17.Size = new System.Drawing.Size(133, 45);
            this.layoutControlItem17.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem17.TextVisible = false;
            // 
            // layoutControlItem18
            // 
            this.layoutControlItem18.Control = this.fullNameLabelControl;
            this.layoutControlItem18.CustomizationFormText = "layoutControlItem18";
            this.layoutControlItem18.Location = new System.Drawing.Point(133, 0);
            this.layoutControlItem18.MinSize = new System.Drawing.Size(131, 29);
            this.layoutControlItem18.Name = "layoutControlItem18";
            this.layoutControlItem18.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 2, 10, 10);
            this.layoutControlItem18.Size = new System.Drawing.Size(849, 45);
            this.layoutControlItem18.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem18.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem18.TextVisible = false;
            // 
            // layoutControlItem10
            // 
            this.layoutControlItem10.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlItem10.AppearanceItemCaption.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.layoutControlItem10.Control = this.descriptionMemoEdit;
            this.layoutControlItem10.CustomizationFormText = "SUBJECT";
            this.layoutControlItem10.Location = new System.Drawing.Point(377, 55);
            this.layoutControlItem10.MinSize = new System.Drawing.Size(85, 20);
            this.layoutControlItem10.Name = "layoutControlItem10";
            this.layoutControlItem10.Size = new System.Drawing.Size(605, 88);
            this.layoutControlItem10.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem10.Text = "SUJET";
            this.layoutControlItem10.TextSize = new System.Drawing.Size(87, 17);
            // 
            // layoutControlItem1
            // 
            this.layoutControlItem1.Control = this.ownerLookUpEdit;
            this.layoutControlItem1.CustomizationFormText = "OWNER";
            this.layoutControlItem1.Location = new System.Drawing.Point(0, 55);
            this.layoutControlItem1.Name = "layoutControlItem1";
            this.layoutControlItem1.Size = new System.Drawing.Size(321, 46);
            this.layoutControlItem1.Text = "Responsable";
            this.layoutControlItem1.TextSize = new System.Drawing.Size(87, 17);
            // 
            // emptySpaceItem4
            // 
            this.emptySpaceItem4.AllowHotTrack = false;
            this.emptySpaceItem4.CustomizationFormText = "emptySpaceItem4";
            this.emptySpaceItem4.Location = new System.Drawing.Point(0, 425);
            this.emptySpaceItem4.Name = "emptySpaceItem4";
            this.emptySpaceItem4.Size = new System.Drawing.Size(982, 10);
            this.emptySpaceItem4.TextSize = new System.Drawing.Size(0, 0);
            // 
            // emptySpaceItem2
            // 
            this.emptySpaceItem2.AllowHotTrack = false;
            this.emptySpaceItem2.CustomizationFormText = "emptySpaceItem2";
            this.emptySpaceItem2.Location = new System.Drawing.Point(0, 193);
            this.emptySpaceItem2.MaxSize = new System.Drawing.Size(0, 24);
            this.emptySpaceItem2.MinSize = new System.Drawing.Size(104, 24);
            this.emptySpaceItem2.Name = "emptySpaceItem2";
            this.emptySpaceItem2.Size = new System.Drawing.Size(321, 24);
            this.emptySpaceItem2.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.emptySpaceItem2.TextSize = new System.Drawing.Size(0, 0);
            // 
            // emptySpaceItem1
            // 
            this.emptySpaceItem1.AllowHotTrack = false;
            this.emptySpaceItem1.CustomizationFormText = "emptySpaceItem1";
            this.emptySpaceItem1.Location = new System.Drawing.Point(0, 309);
            this.emptySpaceItem1.MaxSize = new System.Drawing.Size(0, 24);
            this.emptySpaceItem1.MinSize = new System.Drawing.Size(104, 24);
            this.emptySpaceItem1.Name = "emptySpaceItem1";
            this.emptySpaceItem1.Size = new System.Drawing.Size(321, 24);
            this.emptySpaceItem1.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.emptySpaceItem1.TextSize = new System.Drawing.Size(0, 0);
            // 
            // emptySpaceItem5
            // 
            this.emptySpaceItem5.AllowHotTrack = false;
            this.emptySpaceItem5.CustomizationFormText = "emptySpaceItem5";
            this.emptySpaceItem5.Location = new System.Drawing.Point(0, 481);
            this.emptySpaceItem5.Name = "emptySpaceItem5";
            this.emptySpaceItem5.Size = new System.Drawing.Size(982, 30);
            this.emptySpaceItem5.TextSize = new System.Drawing.Size(0, 0);
            // 
            // emptySpaceItem6
            // 
            this.emptySpaceItem6.AllowHotTrack = false;
            this.emptySpaceItem6.CustomizationFormText = "emptySpaceItem6";
            this.emptySpaceItem6.Location = new System.Drawing.Point(0, 45);
            this.emptySpaceItem6.Name = "emptySpaceItem6";
            this.emptySpaceItem6.Size = new System.Drawing.Size(982, 10);
            this.emptySpaceItem6.TextSize = new System.Drawing.Size(0, 0);
            // 
            // emptySpaceItem7
            // 
            this.emptySpaceItem7.AllowHotTrack = false;
            this.emptySpaceItem7.CustomizationFormText = "emptySpaceItem7";
            this.emptySpaceItem7.Location = new System.Drawing.Point(321, 55);
            this.emptySpaceItem7.Name = "emptySpaceItem7";
            this.emptySpaceItem7.Size = new System.Drawing.Size(56, 370);
            this.emptySpaceItem7.TextSize = new System.Drawing.Size(0, 0);
            // 
            // emptySpaceItem8
            // 
            this.emptySpaceItem8.AllowHotTrack = false;
            this.emptySpaceItem8.CustomizationFormText = "emptySpaceItem8";
            this.emptySpaceItem8.Location = new System.Drawing.Point(377, 355);
            this.emptySpaceItem8.MaxSize = new System.Drawing.Size(0, 24);
            this.emptySpaceItem8.MinSize = new System.Drawing.Size(10, 24);
            this.emptySpaceItem8.Name = "emptySpaceItem8";
            this.emptySpaceItem8.Size = new System.Drawing.Size(605, 24);
            this.emptySpaceItem8.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.emptySpaceItem8.TextSize = new System.Drawing.Size(0, 0);
            // 
            // emptySpaceItem9
            // 
            this.emptySpaceItem9.AllowHotTrack = false;
            this.emptySpaceItem9.CustomizationFormText = "emptySpaceItem9";
            this.emptySpaceItem9.Location = new System.Drawing.Point(865, 435);
            this.emptySpaceItem9.MaxSize = new System.Drawing.Size(12, 0);
            this.emptySpaceItem9.MinSize = new System.Drawing.Size(12, 34);
            this.emptySpaceItem9.Name = "emptySpaceItem9";
            this.emptySpaceItem9.Size = new System.Drawing.Size(12, 46);
            this.emptySpaceItem9.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.emptySpaceItem9.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem3
            // 
            this.layoutControlItem3.Control = this.assignedToLookUpEdit;
            this.layoutControlItem3.CustomizationFormText = "layoutControlItem2";
            this.layoutControlItem3.Location = new System.Drawing.Point(0, 24);
            this.layoutControlItem3.Name = "layoutControlItem2";
            this.layoutControlItem3.Size = new System.Drawing.Size(755, 307);
            this.layoutControlItem3.TextSize = new System.Drawing.Size(93, 13);
            // 
            // ModifierCongés
            // 
            this.Appearance.BackColor = System.Drawing.Color.White;
            this.Appearance.Options.UseBackColor = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.layout);
            this.Name = "ModifierCongés";
            this.Size = new System.Drawing.Size(1002, 531);
            ((System.ComponentModel.ISupportInitialize)(this.layout)).EndInit();
            this.layout.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.taskBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbReminderDate.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbReminderDate.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbReminder.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.descriptionMemoEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.subjectMemoEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dueDateEdit.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dueDateEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.startDateEdit.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.startDateEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.linkedToLookUpEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.assignedToLookUpEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ownerLookUpEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.statusImageComboBoxEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.statusImageList)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.priorityImageComboBoxEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.priorityImageList)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbReminderTime.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private  DevExpress.XtraDataLayout.DataLayoutControl layout;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup1;
        private DevExpress.XtraEditors.LabelControl fullNameLabelControl;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.SimpleButton cancelSimpleButton;
        private DevExpress.XtraEditors.SimpleButton saveSimpleButton;
        private DevExpress.XtraEditors.DateEdit cbReminderDate;
        private DevExpress.XtraEditors.CheckEdit cbReminder;
        private DevExpress.XtraEditors.MemoEdit descriptionMemoEdit;
        private DevExpress.XtraEditors.MemoEdit subjectMemoEdit;
        private DevExpress.XtraEditors.DateEdit dueDateEdit;
        private DevExpress.XtraEditors.DateEdit startDateEdit;
        private DevExpress.XtraEditors.ImageComboBoxEdit linkedToLookUpEdit;
        private DevExpress.XtraEditors.LookUpEdit assignedToLookUpEdit;
        private DevExpress.XtraEditors.LookUpEdit ownerLookUpEdit;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem4;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem5;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem6;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem7;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem8;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem9;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem10;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem11;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem12;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem13;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem3;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem15;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem16;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem17;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem18;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem3;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem4;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem2;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem5;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem6;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem7;
        private System.Windows.Forms.BindingSource taskBindingSource;
        private  DevExpress.Utils.ImageCollection priorityImageList;
        private  DevExpress.Utils.ImageCollection statusImageList;
        private DevExpress.XtraEditors.ImageComboBoxEdit statusImageComboBoxEdit;
        private DevExpress.XtraEditors.ImageComboBoxEdit priorityImageComboBoxEdit;
        private DevExpress.XtraEditors.TimeEdit cbReminderTime;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem8;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem9;
    }
}

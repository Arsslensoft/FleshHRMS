﻿namespace FHRMS.Modules.Customers {
    partial class  StateUC{

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        public void InitializeComponent() {
            this.stateLookUpEdit = new DevExpress.XtraEditors.LookUpEdit();
            ((System.ComponentModel.ISupportInitialize)(this.stateLookUpEdit.Properties)).BeginInit();
            this.SuspendLayout();
            this.stateLookUpEdit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.stateLookUpEdit.Location = new System.Drawing.Point(0, 0);
            this.stateLookUpEdit.Name = "stateLookUpEdit";
            this.stateLookUpEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.stateLookUpEdit.Size = new System.Drawing.Size(300, 40);
            this.stateLookUpEdit.TabIndex = 0;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.stateLookUpEdit);
            this.Name = "StateUC";
            this.Size = new System.Drawing.Size(300, 41);
            ((System.ComponentModel.ISupportInitialize)(this.stateLookUpEdit.Properties)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        public DevExpress.XtraEditors.LookUpEdit stateLookUpEdit;

    }
}

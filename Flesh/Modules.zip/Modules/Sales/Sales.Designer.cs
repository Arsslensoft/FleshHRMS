﻿namespace FHRMS.Modules {
    partial class Sales {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if(disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            DevExpress.XtraGrid.GridLevelNode gridLevelNode1 = new DevExpress.XtraGrid.GridLevelNode();
            DevExpress.XtraEditors.AreaChartRangeControlClientView areaChartRangeControlClientView1 = new DevExpress.XtraEditors.AreaChartRangeControlClientView();
            DevExpress.XtraBars.Ribbon.GalleryItemGroup galleryItemGroup1 = new DevExpress.XtraBars.Ribbon.GalleryItemGroup();
            DevExpress.XtraCharts.Series series1 = new DevExpress.XtraCharts.Series();
            DevExpress.XtraCharts.DoughnutSeriesLabel doughnutSeriesLabel1 = new DevExpress.XtraCharts.DoughnutSeriesLabel();
            DevExpress.XtraCharts.DoughnutSeriesView doughnutSeriesView1 = new DevExpress.XtraCharts.DoughnutSeriesView();
            DevExpress.XtraCharts.DoughnutSeriesView doughnutSeriesView2 = new DevExpress.XtraCharts.DoughnutSeriesView();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Sales));
            DevExpress.XtraEditors.TileItemElement tileItemElement1 = new DevExpress.XtraEditors.TileItemElement();
            DevExpress.XtraEditors.TileItemElement tileItemElement2 = new DevExpress.XtraEditors.TileItemElement();
            DevExpress.XtraEditors.TileItemElement tileItemElement3 = new DevExpress.XtraEditors.TileItemElement();
            DevExpress.XtraEditors.TileItemElement tileItemElement4 = new DevExpress.XtraEditors.TileItemElement();
            DevExpress.XtraEditors.TileItemElement tileItemElement5 = new DevExpress.XtraEditors.TileItemElement();
            DevExpress.XtraEditors.TileItemElement tileItemElement6 = new DevExpress.XtraEditors.TileItemElement();
            DevExpress.XtraEditors.TileItemElement tileItemElement7 = new DevExpress.XtraEditors.TileItemElement();
            DevExpress.XtraEditors.TileItemElement tileItemElement8 = new DevExpress.XtraEditors.TileItemElement();
            DevExpress.XtraEditors.TileItemElement tileItemElement9 = new DevExpress.XtraEditors.TileItemElement();
            DevExpress.XtraEditors.TileItemElement tileItemElement10 = new DevExpress.XtraEditors.TileItemElement();
            DevExpress.XtraEditors.TileItemElement tileItemElement11 = new DevExpress.XtraEditors.TileItemElement();
            DevExpress.XtraEditors.TileItemElement tileItemElement12 = new DevExpress.XtraEditors.TileItemElement();
            DevExpress.XtraEditors.TileItemElement tileItemElement13 = new DevExpress.XtraEditors.TileItemElement();
            DevExpress.XtraEditors.TileItemElement tileItemElement14 = new DevExpress.XtraEditors.TileItemElement();
            DevExpress.XtraCharts.UI.ChartControlCommandGalleryItemGroup2DColumn chartControlCommandGalleryItemGroup2DColumn1 = new DevExpress.XtraCharts.UI.ChartControlCommandGalleryItemGroup2DColumn();
            DevExpress.XtraCharts.UI.CreateBarChartItem createBarChartItem1 = new DevExpress.XtraCharts.UI.CreateBarChartItem();
            DevExpress.XtraCharts.UI.CreateFullStackedBarChartItem createFullStackedBarChartItem1 = new DevExpress.XtraCharts.UI.CreateFullStackedBarChartItem();
            DevExpress.XtraCharts.UI.CreateSideBySideFullStackedBarChartItem createSideBySideFullStackedBarChartItem1 = new DevExpress.XtraCharts.UI.CreateSideBySideFullStackedBarChartItem();
            DevExpress.XtraCharts.UI.CreateSideBySideStackedBarChartItem createSideBySideStackedBarChartItem1 = new DevExpress.XtraCharts.UI.CreateSideBySideStackedBarChartItem();
            DevExpress.XtraCharts.UI.CreateStackedBarChartItem createStackedBarChartItem1 = new DevExpress.XtraCharts.UI.CreateStackedBarChartItem();
            DevExpress.XtraCharts.UI.ChartControlCommandGalleryItemGroup3DColumn chartControlCommandGalleryItemGroup3DColumn1 = new DevExpress.XtraCharts.UI.ChartControlCommandGalleryItemGroup3DColumn();
            DevExpress.XtraCharts.UI.CreateBar3DChartItem createBar3DChartItem1 = new DevExpress.XtraCharts.UI.CreateBar3DChartItem();
            DevExpress.XtraCharts.UI.CreateFullStackedBar3DChartItem createFullStackedBar3DChartItem1 = new DevExpress.XtraCharts.UI.CreateFullStackedBar3DChartItem();
            DevExpress.XtraCharts.UI.CreateManhattanBarChartItem createManhattanBarChartItem1 = new DevExpress.XtraCharts.UI.CreateManhattanBarChartItem();
            DevExpress.XtraCharts.UI.CreateSideBySideFullStackedBar3DChartItem createSideBySideFullStackedBar3DChartItem1 = new DevExpress.XtraCharts.UI.CreateSideBySideFullStackedBar3DChartItem();
            DevExpress.XtraCharts.UI.CreateSideBySideStackedBar3DChartItem createSideBySideStackedBar3DChartItem1 = new DevExpress.XtraCharts.UI.CreateSideBySideStackedBar3DChartItem();
            DevExpress.XtraCharts.UI.CreateStackedBar3DChartItem createStackedBar3DChartItem1 = new DevExpress.XtraCharts.UI.CreateStackedBar3DChartItem();
            DevExpress.XtraCharts.UI.ChartControlCommandGalleryItemGroupCylinderColumn chartControlCommandGalleryItemGroupCylinderColumn1 = new DevExpress.XtraCharts.UI.ChartControlCommandGalleryItemGroupCylinderColumn();
            DevExpress.XtraCharts.UI.CreateCylinderBar3DChartItem createCylinderBar3DChartItem1 = new DevExpress.XtraCharts.UI.CreateCylinderBar3DChartItem();
            DevExpress.XtraCharts.UI.CreateCylinderFullStackedBar3DChartItem createCylinderFullStackedBar3DChartItem1 = new DevExpress.XtraCharts.UI.CreateCylinderFullStackedBar3DChartItem();
            DevExpress.XtraCharts.UI.CreateCylinderManhattanBarChartItem createCylinderManhattanBarChartItem1 = new DevExpress.XtraCharts.UI.CreateCylinderManhattanBarChartItem();
            DevExpress.XtraCharts.UI.CreateCylinderSideBySideFullStackedBar3DChartItem createCylinderSideBySideFullStackedBar3DChartItem1 = new DevExpress.XtraCharts.UI.CreateCylinderSideBySideFullStackedBar3DChartItem();
            DevExpress.XtraCharts.UI.CreateCylinderSideBySideStackedBar3DChartItem createCylinderSideBySideStackedBar3DChartItem1 = new DevExpress.XtraCharts.UI.CreateCylinderSideBySideStackedBar3DChartItem();
            DevExpress.XtraCharts.UI.CreateCylinderStackedBar3DChartItem createCylinderStackedBar3DChartItem1 = new DevExpress.XtraCharts.UI.CreateCylinderStackedBar3DChartItem();
            DevExpress.XtraCharts.UI.ChartControlCommandGalleryItemGroupConeColumn chartControlCommandGalleryItemGroupConeColumn1 = new DevExpress.XtraCharts.UI.ChartControlCommandGalleryItemGroupConeColumn();
            DevExpress.XtraCharts.UI.CreateConeBar3DChartItem createConeBar3DChartItem1 = new DevExpress.XtraCharts.UI.CreateConeBar3DChartItem();
            DevExpress.XtraCharts.UI.CreateConeFullStackedBar3DChartItem createConeFullStackedBar3DChartItem1 = new DevExpress.XtraCharts.UI.CreateConeFullStackedBar3DChartItem();
            DevExpress.XtraCharts.UI.CreateConeManhattanBarChartItem createConeManhattanBarChartItem1 = new DevExpress.XtraCharts.UI.CreateConeManhattanBarChartItem();
            DevExpress.XtraCharts.UI.CreateConeSideBySideFullStackedBar3DChartItem createConeSideBySideFullStackedBar3DChartItem1 = new DevExpress.XtraCharts.UI.CreateConeSideBySideFullStackedBar3DChartItem();
            DevExpress.XtraCharts.UI.CreateConeSideBySideStackedBar3DChartItem createConeSideBySideStackedBar3DChartItem1 = new DevExpress.XtraCharts.UI.CreateConeSideBySideStackedBar3DChartItem();
            DevExpress.XtraCharts.UI.CreateConeStackedBar3DChartItem createConeStackedBar3DChartItem1 = new DevExpress.XtraCharts.UI.CreateConeStackedBar3DChartItem();
            DevExpress.XtraCharts.UI.ChartControlCommandGalleryItemGroupPyramidColumn chartControlCommandGalleryItemGroupPyramidColumn1 = new DevExpress.XtraCharts.UI.ChartControlCommandGalleryItemGroupPyramidColumn();
            DevExpress.XtraCharts.UI.CreatePyramidBar3DChartItem createPyramidBar3DChartItem1 = new DevExpress.XtraCharts.UI.CreatePyramidBar3DChartItem();
            DevExpress.XtraCharts.UI.CreatePyramidFullStackedBar3DChartItem createPyramidFullStackedBar3DChartItem1 = new DevExpress.XtraCharts.UI.CreatePyramidFullStackedBar3DChartItem();
            DevExpress.XtraCharts.UI.CreatePyramidManhattanBarChartItem createPyramidManhattanBarChartItem1 = new DevExpress.XtraCharts.UI.CreatePyramidManhattanBarChartItem();
            DevExpress.XtraCharts.UI.CreatePyramidSideBySideFullStackedBar3DChartItem createPyramidSideBySideFullStackedBar3DChartItem1 = new DevExpress.XtraCharts.UI.CreatePyramidSideBySideFullStackedBar3DChartItem();
            DevExpress.XtraCharts.UI.CreatePyramidSideBySideStackedBar3DChartItem createPyramidSideBySideStackedBar3DChartItem1 = new DevExpress.XtraCharts.UI.CreatePyramidSideBySideStackedBar3DChartItem();
            DevExpress.XtraCharts.UI.CreatePyramidStackedBar3DChartItem createPyramidStackedBar3DChartItem1 = new DevExpress.XtraCharts.UI.CreatePyramidStackedBar3DChartItem();
            DevExpress.XtraCharts.UI.ChartControlCommandGalleryItemGroup2DLine chartControlCommandGalleryItemGroup2DLine1 = new DevExpress.XtraCharts.UI.ChartControlCommandGalleryItemGroup2DLine();
            DevExpress.XtraCharts.UI.CreateLineChartItem createLineChartItem1 = new DevExpress.XtraCharts.UI.CreateLineChartItem();
            DevExpress.XtraCharts.UI.CreateFullStackedLineChartItem createFullStackedLineChartItem1 = new DevExpress.XtraCharts.UI.CreateFullStackedLineChartItem();
            DevExpress.XtraCharts.UI.CreateScatterLineChartItem createScatterLineChartItem1 = new DevExpress.XtraCharts.UI.CreateScatterLineChartItem();
            DevExpress.XtraCharts.UI.CreateSplineChartItem createSplineChartItem1 = new DevExpress.XtraCharts.UI.CreateSplineChartItem();
            DevExpress.XtraCharts.UI.CreateStackedLineChartItem createStackedLineChartItem1 = new DevExpress.XtraCharts.UI.CreateStackedLineChartItem();
            DevExpress.XtraCharts.UI.CreateStepLineChartItem createStepLineChartItem1 = new DevExpress.XtraCharts.UI.CreateStepLineChartItem();
            DevExpress.XtraCharts.UI.ChartControlCommandGalleryItemGroup3DLine chartControlCommandGalleryItemGroup3DLine1 = new DevExpress.XtraCharts.UI.ChartControlCommandGalleryItemGroup3DLine();
            DevExpress.XtraCharts.UI.CreateLine3DChartItem createLine3DChartItem1 = new DevExpress.XtraCharts.UI.CreateLine3DChartItem();
            DevExpress.XtraCharts.UI.CreateFullStackedLine3DChartItem createFullStackedLine3DChartItem1 = new DevExpress.XtraCharts.UI.CreateFullStackedLine3DChartItem();
            DevExpress.XtraCharts.UI.CreateSpline3DChartItem createSpline3DChartItem1 = new DevExpress.XtraCharts.UI.CreateSpline3DChartItem();
            DevExpress.XtraCharts.UI.CreateStackedLine3DChartItem createStackedLine3DChartItem1 = new DevExpress.XtraCharts.UI.CreateStackedLine3DChartItem();
            DevExpress.XtraCharts.UI.CreateStepLine3DChartItem createStepLine3DChartItem1 = new DevExpress.XtraCharts.UI.CreateStepLine3DChartItem();
            DevExpress.XtraCharts.UI.ChartControlCommandGalleryItemGroup2DPie chartControlCommandGalleryItemGroup2DPie1 = new DevExpress.XtraCharts.UI.ChartControlCommandGalleryItemGroup2DPie();
            DevExpress.XtraCharts.UI.CreatePieChartItem createPieChartItem1 = new DevExpress.XtraCharts.UI.CreatePieChartItem();
            DevExpress.XtraCharts.UI.CreateDoughnutChartItem createDoughnutChartItem1 = new DevExpress.XtraCharts.UI.CreateDoughnutChartItem();
            DevExpress.XtraCharts.UI.CreateNestedDoughnutChartItem createNestedDoughnutChartItem1 = new DevExpress.XtraCharts.UI.CreateNestedDoughnutChartItem();
            DevExpress.XtraCharts.UI.ChartControlCommandGalleryItemGroup3DPie chartControlCommandGalleryItemGroup3DPie1 = new DevExpress.XtraCharts.UI.ChartControlCommandGalleryItemGroup3DPie();
            DevExpress.XtraCharts.UI.CreatePie3DChartItem createPie3DChartItem1 = new DevExpress.XtraCharts.UI.CreatePie3DChartItem();
            DevExpress.XtraCharts.UI.CreateDoughnut3DChartItem createDoughnut3DChartItem1 = new DevExpress.XtraCharts.UI.CreateDoughnut3DChartItem();
            DevExpress.XtraCharts.UI.ChartControlCommandGalleryItemGroup2DBar chartControlCommandGalleryItemGroup2DBar1 = new DevExpress.XtraCharts.UI.ChartControlCommandGalleryItemGroup2DBar();
            DevExpress.XtraCharts.UI.CreateRotatedBarChartItem createRotatedBarChartItem1 = new DevExpress.XtraCharts.UI.CreateRotatedBarChartItem();
            DevExpress.XtraCharts.UI.CreateRotatedFullStackedBarChartItem createRotatedFullStackedBarChartItem1 = new DevExpress.XtraCharts.UI.CreateRotatedFullStackedBarChartItem();
            DevExpress.XtraCharts.UI.CreateRotatedSideBySideFullStackedBarChartItem createRotatedSideBySideFullStackedBarChartItem1 = new DevExpress.XtraCharts.UI.CreateRotatedSideBySideFullStackedBarChartItem();
            DevExpress.XtraCharts.UI.CreateRotatedSideBySideStackedBarChartItem createRotatedSideBySideStackedBarChartItem1 = new DevExpress.XtraCharts.UI.CreateRotatedSideBySideStackedBarChartItem();
            DevExpress.XtraCharts.UI.CreateRotatedStackedBarChartItem createRotatedStackedBarChartItem1 = new DevExpress.XtraCharts.UI.CreateRotatedStackedBarChartItem();
            DevExpress.XtraCharts.UI.ChartControlCommandGalleryItemGroup2DArea chartControlCommandGalleryItemGroup2DArea1 = new DevExpress.XtraCharts.UI.ChartControlCommandGalleryItemGroup2DArea();
            DevExpress.XtraCharts.UI.CreateAreaChartItem createAreaChartItem1 = new DevExpress.XtraCharts.UI.CreateAreaChartItem();
            DevExpress.XtraCharts.UI.CreateFullStackedAreaChartItem createFullStackedAreaChartItem1 = new DevExpress.XtraCharts.UI.CreateFullStackedAreaChartItem();
            DevExpress.XtraCharts.UI.CreateFullStackedSplineAreaChartItem createFullStackedSplineAreaChartItem1 = new DevExpress.XtraCharts.UI.CreateFullStackedSplineAreaChartItem();
            DevExpress.XtraCharts.UI.CreateSplineAreaChartItem createSplineAreaChartItem1 = new DevExpress.XtraCharts.UI.CreateSplineAreaChartItem();
            DevExpress.XtraCharts.UI.CreateStackedAreaChartItem createStackedAreaChartItem1 = new DevExpress.XtraCharts.UI.CreateStackedAreaChartItem();
            DevExpress.XtraCharts.UI.CreateStackedSplineAreaChartItem createStackedSplineAreaChartItem1 = new DevExpress.XtraCharts.UI.CreateStackedSplineAreaChartItem();
            DevExpress.XtraCharts.UI.CreateStepAreaChartItem createStepAreaChartItem1 = new DevExpress.XtraCharts.UI.CreateStepAreaChartItem();
            DevExpress.XtraCharts.UI.ChartControlCommandGalleryItemGroup3DArea chartControlCommandGalleryItemGroup3DArea1 = new DevExpress.XtraCharts.UI.ChartControlCommandGalleryItemGroup3DArea();
            DevExpress.XtraCharts.UI.CreateArea3DChartItem createArea3DChartItem1 = new DevExpress.XtraCharts.UI.CreateArea3DChartItem();
            DevExpress.XtraCharts.UI.CreateFullStackedArea3DChartItem createFullStackedArea3DChartItem1 = new DevExpress.XtraCharts.UI.CreateFullStackedArea3DChartItem();
            DevExpress.XtraCharts.UI.CreateFullStackedSplineArea3DChartItem createFullStackedSplineArea3DChartItem1 = new DevExpress.XtraCharts.UI.CreateFullStackedSplineArea3DChartItem();
            DevExpress.XtraCharts.UI.CreateSplineArea3DChartItem createSplineArea3DChartItem1 = new DevExpress.XtraCharts.UI.CreateSplineArea3DChartItem();
            DevExpress.XtraCharts.UI.CreateStackedArea3DChartItem createStackedArea3DChartItem1 = new DevExpress.XtraCharts.UI.CreateStackedArea3DChartItem();
            DevExpress.XtraCharts.UI.CreateStackedSplineArea3DChartItem createStackedSplineArea3DChartItem1 = new DevExpress.XtraCharts.UI.CreateStackedSplineArea3DChartItem();
            DevExpress.XtraCharts.UI.CreateStepArea3DChartItem createStepArea3DChartItem1 = new DevExpress.XtraCharts.UI.CreateStepArea3DChartItem();
            DevExpress.XtraCharts.UI.ChartControlCommandGalleryItemGroupPoint chartControlCommandGalleryItemGroupPoint1 = new DevExpress.XtraCharts.UI.ChartControlCommandGalleryItemGroupPoint();
            DevExpress.XtraCharts.UI.CreatePointChartItem createPointChartItem1 = new DevExpress.XtraCharts.UI.CreatePointChartItem();
            DevExpress.XtraCharts.UI.CreateBubbleChartItem createBubbleChartItem1 = new DevExpress.XtraCharts.UI.CreateBubbleChartItem();
            DevExpress.XtraCharts.UI.ChartControlCommandGalleryItemGroupFunnel chartControlCommandGalleryItemGroupFunnel1 = new DevExpress.XtraCharts.UI.ChartControlCommandGalleryItemGroupFunnel();
            DevExpress.XtraCharts.UI.CreateFunnelChartItem createFunnelChartItem1 = new DevExpress.XtraCharts.UI.CreateFunnelChartItem();
            DevExpress.XtraCharts.UI.CreateFunnel3DChartItem createFunnel3DChartItem1 = new DevExpress.XtraCharts.UI.CreateFunnel3DChartItem();
            DevExpress.XtraCharts.UI.ChartControlCommandGalleryItemGroupFinancial chartControlCommandGalleryItemGroupFinancial1 = new DevExpress.XtraCharts.UI.ChartControlCommandGalleryItemGroupFinancial();
            DevExpress.XtraCharts.UI.CreateStockChartItem createStockChartItem1 = new DevExpress.XtraCharts.UI.CreateStockChartItem();
            DevExpress.XtraCharts.UI.CreateCandleStickChartItem createCandleStickChartItem1 = new DevExpress.XtraCharts.UI.CreateCandleStickChartItem();
            DevExpress.XtraCharts.UI.ChartControlCommandGalleryItemGroupRadar chartControlCommandGalleryItemGroupRadar1 = new DevExpress.XtraCharts.UI.ChartControlCommandGalleryItemGroupRadar();
            DevExpress.XtraCharts.UI.CreateRadarPointChartItem createRadarPointChartItem1 = new DevExpress.XtraCharts.UI.CreateRadarPointChartItem();
            DevExpress.XtraCharts.UI.CreateRadarLineChartItem createRadarLineChartItem1 = new DevExpress.XtraCharts.UI.CreateRadarLineChartItem();
            DevExpress.XtraCharts.UI.CreateRadarAreaChartItem createRadarAreaChartItem1 = new DevExpress.XtraCharts.UI.CreateRadarAreaChartItem();
            DevExpress.XtraCharts.UI.ChartControlCommandGalleryItemGroupPolar chartControlCommandGalleryItemGroupPolar1 = new DevExpress.XtraCharts.UI.ChartControlCommandGalleryItemGroupPolar();
            DevExpress.XtraCharts.UI.CreatePolarPointChartItem createPolarPointChartItem1 = new DevExpress.XtraCharts.UI.CreatePolarPointChartItem();
            DevExpress.XtraCharts.UI.CreatePolarLineChartItem createPolarLineChartItem1 = new DevExpress.XtraCharts.UI.CreatePolarLineChartItem();
            DevExpress.XtraCharts.UI.CreatePolarAreaChartItem createPolarAreaChartItem1 = new DevExpress.XtraCharts.UI.CreatePolarAreaChartItem();
            DevExpress.XtraCharts.UI.ChartControlCommandGalleryItemGroupRange chartControlCommandGalleryItemGroupRange1 = new DevExpress.XtraCharts.UI.ChartControlCommandGalleryItemGroupRange();
            DevExpress.XtraCharts.UI.CreateRangeBarChartItem createRangeBarChartItem1 = new DevExpress.XtraCharts.UI.CreateRangeBarChartItem();
            DevExpress.XtraCharts.UI.CreateSideBySideRangeBarChartItem createSideBySideRangeBarChartItem1 = new DevExpress.XtraCharts.UI.CreateSideBySideRangeBarChartItem();
            DevExpress.XtraCharts.UI.CreateRangeAreaChartItem createRangeAreaChartItem1 = new DevExpress.XtraCharts.UI.CreateRangeAreaChartItem();
            DevExpress.XtraCharts.UI.CreateRangeArea3DChartItem createRangeArea3DChartItem1 = new DevExpress.XtraCharts.UI.CreateRangeArea3DChartItem();
            DevExpress.XtraCharts.UI.ChartControlCommandGalleryItemGroupGantt chartControlCommandGalleryItemGroupGantt1 = new DevExpress.XtraCharts.UI.ChartControlCommandGalleryItemGroupGantt();
            DevExpress.XtraCharts.UI.CreateGanttChartItem createGanttChartItem1 = new DevExpress.XtraCharts.UI.CreateGanttChartItem();
            DevExpress.XtraCharts.UI.CreateSideBySideGanttChartItem createSideBySideGanttChartItem1 = new DevExpress.XtraCharts.UI.CreateSideBySideGanttChartItem();
            this.orderItemsGridView = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.ProductGC = new DevExpress.XtraGrid.Columns.GridColumn();
            this.unitsGridColumn = new DevExpress.XtraGrid.Columns.GridColumn();
            this.unitPriceGridColumn = new DevExpress.XtraGrid.Columns.GridColumn();
            this.totalGridColumn = new DevExpress.XtraGrid.Columns.GridColumn();
            this.discountGridColumn = new DevExpress.XtraGrid.Columns.GridColumn();
            this.salesGridControl = new DevExpress.XtraGrid.GridControl();
            this.salesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.salesGridView = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colInvoiceNumber = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colCustomer = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colStore = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colOrderDate = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colTotalAmount = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemProgressBar1 = new DevExpress.XtraEditors.Repository.RepositoryItemProgressBar();
            this.repositoryItemComboBox1 = new DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox();
            this.rangeControl = new DevExpress.XtraEditors.RangeControl();
            this.dateTimeChartRangeControlClient1 = new DevExpress.XtraEditors.DateTimeChartRangeControlClient();
            this.dataLayoutControl1 = new DevExpress.XtraDataLayout.DataLayoutControl();
            this.dropDownButton1 = new DevExpress.XtraEditors.DropDownButton();
            this.popupMenu1 = new DevExpress.XtraBars.Ribbon.GalleryDropDown(this.components);
            this.barManager1 = new DevExpress.XtraBars.BarManager(this.components);
            this.barDockControlTop = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlBottom = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlLeft = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlRight = new DevExpress.XtraBars.BarDockControl();
            this.barButtonItemContacts = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItemStores = new DevExpress.XtraBars.BarButtonItem();
            this.chartControl = new DevExpress.XtraCharts.ChartControl();
            this.layoutControlGroup1 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem1 = new DevExpress.XtraLayout.LayoutControlItem();
            this.salesSLI = new DevExpress.XtraLayout.SimpleLabelItem();
            this.buttonHide = new DevExpress.XtraLayout.SimpleLabelItem();
            this.layoutControlItem2 = new DevExpress.XtraLayout.LayoutControlItem();
            this.lcgChart = new DevExpress.XtraLayout.LayoutControlGroup();
            this.lcSales = new DevExpress.XtraLayout.LayoutControlItem();
            this.chartControlLCI = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem = new DevExpress.XtraLayout.EmptySpaceItem();
            this.simpleLabelItem7 = new DevExpress.XtraLayout.SimpleLabelItem();
            this.simpleLabelItem4 = new DevExpress.XtraLayout.SimpleLabelItem();
            this.simpleLabelItem3 = new DevExpress.XtraLayout.SimpleLabelItem();
            this.simpleLabelItem2 = new DevExpress.XtraLayout.SimpleLabelItem();
            this.simpleLabelItem1 = new DevExpress.XtraLayout.SimpleLabelItem();
            this.simpleLabelItem5 = new DevExpress.XtraLayout.SimpleLabelItem();
            this.tileItemHighPriority = new DevExpress.XtraEditors.TileItem();
            this.tileItemUrgent = new DevExpress.XtraEditors.TileItem();
            this.tileItemCompleted = new DevExpress.XtraEditors.TileItem();
            this.tileItemDeferred = new DevExpress.XtraEditors.TileItem();
            this.tileItemNotStartedTask = new DevExpress.XtraEditors.TileItem();
            this.tileItemInProgress = new DevExpress.XtraEditors.TileItem();
            this.tileItemAll = new DevExpress.XtraEditors.TileItem();
            this.commandBarGalleryDropDown1 = new DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(this.components);
            this.commandBarGalleryDropDown2 = new DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(this.components);
            this.commandBarGalleryDropDown3 = new DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(this.components);
            this.commandBarGalleryDropDown4 = new DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(this.components);
            this.commandBarGalleryDropDown5 = new DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(this.components);
            this.commandBarGalleryDropDown6 = new DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(this.components);
            this.commandBarGalleryDropDown7 = new DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(this.components);
            this.commandBarGalleryDropDown8 = new DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.orderItemsGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.salesGridControl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.salesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.salesGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemProgressBar1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rangeControl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateTimeChartRangeControlClient1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataLayoutControl1)).BeginInit();
            this.dataLayoutControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.popupMenu1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.barManager1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartControl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(series1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(doughnutSeriesLabel1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(doughnutSeriesView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(doughnutSeriesView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.salesSLI)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.buttonHide)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lcgChart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lcSales)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartControlLCI)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown8)).BeginInit();
            this.SuspendLayout();
            // 
            // orderItemsGridView
            // 
            this.orderItemsGridView.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.ProductGC,
            this.unitsGridColumn,
            this.unitPriceGridColumn,
            this.totalGridColumn,
            this.discountGridColumn});
            this.orderItemsGridView.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.None;
            this.orderItemsGridView.GridControl = this.salesGridControl;
            this.orderItemsGridView.Name = "orderItemsGridView";
            this.orderItemsGridView.OptionsBehavior.Editable = false;
            this.orderItemsGridView.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.orderItemsGridView.OptionsView.ShowGroupPanel = false;
            this.orderItemsGridView.OptionsView.ShowIndicator = false;
            this.orderItemsGridView.PreviewFieldName = "OrderItems";
            // 
            // ProductGC
            // 
            this.ProductGC.Caption = "Product";
            this.ProductGC.FieldName = "Product.Name";
            this.ProductGC.Name = "ProductGC";
            this.ProductGC.Visible = true;
            this.ProductGC.VisibleIndex = 0;
            this.ProductGC.Width = 159;
            // 
            // unitsGridColumn
            // 
            this.unitsGridColumn.Caption = "Units";
            this.unitsGridColumn.FieldName = "ProductUnits";
            this.unitsGridColumn.Name = "unitsGridColumn";
            this.unitsGridColumn.OptionsColumn.FixedWidth = true;
            this.unitsGridColumn.Visible = true;
            this.unitsGridColumn.VisibleIndex = 1;
            this.unitsGridColumn.Width = 120;
            // 
            // unitPriceGridColumn
            // 
            this.unitPriceGridColumn.Caption = "Unit Price";
            this.unitPriceGridColumn.DisplayFormat.FormatString = "c";
            this.unitPriceGridColumn.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.unitPriceGridColumn.FieldName = "ProductPrice";
            this.unitPriceGridColumn.Name = "unitPriceGridColumn";
            this.unitPriceGridColumn.OptionsColumn.FixedWidth = true;
            this.unitPriceGridColumn.Visible = true;
            this.unitPriceGridColumn.VisibleIndex = 2;
            this.unitPriceGridColumn.Width = 120;
            // 
            // totalGridColumn
            // 
            this.totalGridColumn.Caption = "Total";
            this.totalGridColumn.DisplayFormat.FormatString = "c";
            this.totalGridColumn.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.totalGridColumn.FieldName = "Total";
            this.totalGridColumn.Name = "totalGridColumn";
            this.totalGridColumn.OptionsColumn.FixedWidth = true;
            this.totalGridColumn.Visible = true;
            this.totalGridColumn.VisibleIndex = 3;
            this.totalGridColumn.Width = 120;
            // 
            // discountGridColumn
            // 
            this.discountGridColumn.Caption = "Discount";
            this.discountGridColumn.DisplayFormat.FormatString = "c";
            this.discountGridColumn.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.discountGridColumn.FieldName = "Discount";
            this.discountGridColumn.Name = "discountGridColumn";
            this.discountGridColumn.OptionsColumn.FixedWidth = true;
            this.discountGridColumn.Visible = true;
            this.discountGridColumn.VisibleIndex = 4;
            this.discountGridColumn.Width = 120;
            // 
            // salesGridControl
            // 
            this.salesGridControl.DataSource = this.salesBindingSource;
            gridLevelNode1.LevelTemplate = this.orderItemsGridView;
            gridLevelNode1.RelationName = "OrderItems";
            this.salesGridControl.LevelTree.Nodes.AddRange(new DevExpress.XtraGrid.GridLevelNode[] {
            gridLevelNode1});
            this.salesGridControl.Location = new System.Drawing.Point(42, 47);
            this.salesGridControl.MainView = this.salesGridView;
            this.salesGridControl.Name = "salesGridControl";
            this.salesGridControl.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemProgressBar1,
            this.repositoryItemComboBox1});
            this.salesGridControl.Size = new System.Drawing.Size(599, 339);
            this.salesGridControl.TabIndex = 1;
            this.salesGridControl.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.salesGridView,
            this.orderItemsGridView});
            // 
            // salesBindingSource
            // 
            this.salesBindingSource.DataSource = typeof(FHRMS.Data.Order);
            // 
            // salesGridView
            // 
            this.salesGridView.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colInvoiceNumber,
            this.colCustomer,
            this.colStore,
            this.colOrderDate,
            this.colTotalAmount});
            this.salesGridView.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.None;
            this.salesGridView.GridControl = this.salesGridControl;
            this.salesGridView.Name = "salesGridView";
            this.salesGridView.OptionsBehavior.AllowPixelScrolling = DevExpress.Utils.DefaultBoolean.True;
            this.salesGridView.OptionsBehavior.AutoExpandAllGroups = true;
            this.salesGridView.OptionsBehavior.Editable = false;
            this.salesGridView.OptionsCustomization.AllowQuickHideColumns = false;
            this.salesGridView.OptionsDetail.EnableMasterViewMode = false;
            this.salesGridView.OptionsFind.AllowFindPanel = false;
            this.salesGridView.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.salesGridView.OptionsView.ShowFilterPanelMode = DevExpress.XtraGrid.Views.Base.ShowFilterPanelMode.Never;
            this.salesGridView.OptionsView.ShowGroupPanel = false;
            this.salesGridView.OptionsView.ShowIndicator = false;
            this.salesGridView.RowHeight = 10;
            this.salesGridView.SortInfo.AddRange(new DevExpress.XtraGrid.Columns.GridColumnSortInfo[] {
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.colInvoiceNumber, DevExpress.Data.ColumnSortOrder.Descending)});
            this.salesGridView.RowClick += new DevExpress.XtraGrid.Views.Grid.RowClickEventHandler(this.salesGridView_RowClick);
            this.salesGridView.FocusedRowObjectChanged += new DevExpress.XtraGrid.Views.Base.FocusedRowObjectChangedEventHandler(this.salesGridView_FocusedRowObjectChanged);
            // 
            // colInvoiceNumber
            // 
            this.colInvoiceNumber.Caption = "Invoice";
            this.colInvoiceNumber.FieldName = "InvoiceNumber";
            this.colInvoiceNumber.Name = "colInvoiceNumber";
            this.colInvoiceNumber.OptionsColumn.FixedWidth = true;
            this.colInvoiceNumber.Visible = true;
            this.colInvoiceNumber.VisibleIndex = 0;
            this.colInvoiceNumber.Width = 120;
            // 
            // colCustomer
            // 
            this.colCustomer.FieldName = "Customer.Name";
            this.colCustomer.Name = "colCustomer";
            this.colCustomer.Visible = true;
            this.colCustomer.VisibleIndex = 2;
            this.colCustomer.Width = 117;
            // 
            // colStore
            // 
            this.colStore.Caption = "City";
            this.colStore.FieldName = "Store.Address.CityLine";
            this.colStore.Name = "colStore";
            this.colStore.Visible = true;
            this.colStore.VisibleIndex = 3;
            this.colStore.Width = 112;
            // 
            // colOrderDate
            // 
            this.colOrderDate.FieldName = "OrderDate";
            this.colOrderDate.Name = "colOrderDate";
            this.colOrderDate.OptionsColumn.FixedWidth = true;
            this.colOrderDate.Visible = true;
            this.colOrderDate.VisibleIndex = 1;
            this.colOrderDate.Width = 100;
            // 
            // colTotalAmount
            // 
            this.colTotalAmount.DisplayFormat.FormatString = "c";
            this.colTotalAmount.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.colTotalAmount.FieldName = "TotalAmount";
            this.colTotalAmount.Name = "colTotalAmount";
            this.colTotalAmount.OptionsColumn.FixedWidth = true;
            this.colTotalAmount.Visible = true;
            this.colTotalAmount.VisibleIndex = 4;
            this.colTotalAmount.Width = 129;
            // 
            // repositoryItemProgressBar1
            // 
            this.repositoryItemProgressBar1.Name = "repositoryItemProgressBar1";
            this.repositoryItemProgressBar1.ProgressViewStyle = DevExpress.XtraEditors.Controls.ProgressViewStyle.Solid;
            this.repositoryItemProgressBar1.ShowTitle = true;
            // 
            // repositoryItemComboBox1
            // 
            this.repositoryItemComboBox1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox1.Items.AddRange(new DevExpress.XtraEditors.Controls.ImageComboBoxItem[] {
            new DevExpress.XtraEditors.Controls.ImageComboBoxItem("", FHRMS.Data.LeavePriority.Low, 0),
            new DevExpress.XtraEditors.Controls.ImageComboBoxItem("", FHRMS.Data.LeavePriority.Normal, 2),
            new DevExpress.XtraEditors.Controls.ImageComboBoxItem("", FHRMS.Data.LeavePriority.High, 1),
            new DevExpress.XtraEditors.Controls.ImageComboBoxItem("", FHRMS.Data.LeavePriority.Urgent, 1)});
            this.repositoryItemComboBox1.Name = "repositoryItemComboBox1";
            this.repositoryItemComboBox1.PopupSizeable = true;
            // 
            // rangeControl
            // 
            this.rangeControl.AnimateOnDataChange = true;
            this.rangeControl.Client = this.dateTimeChartRangeControlClient1;
            this.rangeControl.Location = new System.Drawing.Point(42, 414);
            this.rangeControl.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.rangeControl.MaximumSize = new System.Drawing.Size(0, 138);
            this.rangeControl.MinimumSize = new System.Drawing.Size(0, 138);
            this.rangeControl.Name = "rangeControl";
            this.rangeControl.ShowZoomScrollBar = false;
            this.rangeControl.Size = new System.Drawing.Size(599, 138);
            this.rangeControl.StyleController = this.dataLayoutControl1;
            this.rangeControl.TabIndex = 28;
            this.rangeControl.Text = "rangeControl1";
            this.rangeControl.RangeChanged += new DevExpress.XtraEditors.RangeChangedEventHandler(this.rangeControl_RangeChanged);
            // 
            // dateTimeChartRangeControlClient1
            // 
            areaChartRangeControlClientView1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(194)))), ((int)(((byte)(224)))));
            this.dateTimeChartRangeControlClient1.DataProvider.TemplateView = areaChartRangeControlClientView1;
            this.dateTimeChartRangeControlClient1.GridOptions.Auto = false;
            this.dateTimeChartRangeControlClient1.GridOptions.GridAlignment = DevExpress.XtraEditors.RangeControlDateTimeGridAlignment.Month;
            this.dateTimeChartRangeControlClient1.GridOptions.SnapAlignment = DevExpress.XtraEditors.RangeControlDateTimeGridAlignment.Month;
            this.dateTimeChartRangeControlClient1.PaletteName = "NatureColors";
            // 
            // dataLayoutControl1
            // 
            this.dataLayoutControl1.AllowCustomization = false;
            this.dataLayoutControl1.BackColor = System.Drawing.Color.White;
            this.dataLayoutControl1.Controls.Add(this.dropDownButton1);
            this.dataLayoutControl1.Controls.Add(this.rangeControl);
            this.dataLayoutControl1.Controls.Add(this.chartControl);
            this.dataLayoutControl1.Controls.Add(this.salesGridControl);
            this.dataLayoutControl1.DataSource = this.salesBindingSource;
            this.dataLayoutControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataLayoutControl1.Location = new System.Drawing.Point(0, 0);
            this.dataLayoutControl1.Name = "dataLayoutControl1";
            this.dataLayoutControl1.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new System.Drawing.Rectangle(487, 203, 864, 685);
            this.dataLayoutControl1.Root = this.layoutControlGroup1;
            this.dataLayoutControl1.Size = new System.Drawing.Size(955, 554);
            this.dataLayoutControl1.TabIndex = 27;
            this.dataLayoutControl1.Text = "dataLayoutControl1";
            // 
            // dropDownButton1
            // 
            this.dropDownButton1.AllowFocus = false;
            this.dropDownButton1.Appearance.FontSizeDelta = 3;
            this.dropDownButton1.Appearance.Options.UseFont = true;
            this.dropDownButton1.AutoWidthInLayoutControl = true;
            this.dropDownButton1.DropDownControl = this.popupMenu1;
            this.dropDownButton1.Location = new System.Drawing.Point(738, 47);
            this.dropDownButton1.Name = "dropDownButton1";
            this.dropDownButton1.Size = new System.Drawing.Size(110, 42);
            this.dropDownButton1.StyleController = this.dataLayoutControl1;
            this.dropDownButton1.TabIndex = 28;
            this.dropDownButton1.Text = "Sales";
            this.dropDownButton1.Click += new System.EventHandler(this.dropDownButton1_Click);
            // 
            // popupMenu1
            // 
            // 
            // 
            // 
            this.popupMenu1.Gallery.Appearance.ItemCaptionAppearance.Disabled.Options.UseFont = true;
            this.popupMenu1.Gallery.Appearance.ItemCaptionAppearance.Hovered.Options.UseFont = true;
            this.popupMenu1.Gallery.Appearance.ItemCaptionAppearance.Normal.Options.UseFont = true;
            this.popupMenu1.Gallery.Appearance.ItemCaptionAppearance.Pressed.Options.UseFont = true;
            this.popupMenu1.Gallery.AutoSize = DevExpress.XtraBars.Ribbon.GallerySizeMode.Both;
            this.popupMenu1.Gallery.ColumnCount = 1;
            this.popupMenu1.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            galleryItemGroup1});
            this.popupMenu1.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left;
            this.popupMenu1.Gallery.ShowGroupCaption = false;
            this.popupMenu1.Gallery.ShowItemImage = false;
            this.popupMenu1.Gallery.ShowItemText = true;
            this.popupMenu1.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.Hide;
            this.popupMenu1.Gallery.StretchItems = true;
            this.popupMenu1.Manager = this.barManager1;
            this.popupMenu1.Name = "popupMenu1";
            this.popupMenu1.ShowNavigationHeader = DevExpress.Utils.DefaultBoolean.True;
            // 
            // barManager1
            // 
            this.barManager1.DockControls.Add(this.barDockControlTop);
            this.barManager1.DockControls.Add(this.barDockControlBottom);
            this.barManager1.DockControls.Add(this.barDockControlLeft);
            this.barManager1.DockControls.Add(this.barDockControlRight);
            this.barManager1.Form = this;
            this.barManager1.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.barButtonItemContacts,
            this.barButtonItemStores});
            this.barManager1.MaxItemId = 2;
            // 
            // barDockControlTop
            // 
            this.barDockControlTop.CausesValidation = false;
            this.barDockControlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.barDockControlTop.Location = new System.Drawing.Point(0, 0);
            this.barDockControlTop.Size = new System.Drawing.Size(955, 0);
            // 
            // barDockControlBottom
            // 
            this.barDockControlBottom.CausesValidation = false;
            this.barDockControlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.barDockControlBottom.Location = new System.Drawing.Point(0, 554);
            this.barDockControlBottom.Size = new System.Drawing.Size(955, 0);
            // 
            // barDockControlLeft
            // 
            this.barDockControlLeft.CausesValidation = false;
            this.barDockControlLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.barDockControlLeft.Location = new System.Drawing.Point(0, 0);
            this.barDockControlLeft.Size = new System.Drawing.Size(0, 554);
            // 
            // barDockControlRight
            // 
            this.barDockControlRight.CausesValidation = false;
            this.barDockControlRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.barDockControlRight.Location = new System.Drawing.Point(955, 0);
            this.barDockControlRight.Size = new System.Drawing.Size(0, 554);
            // 
            // barButtonItemContacts
            // 
            this.barButtonItemContacts.Caption = "Contacts";
            this.barButtonItemContacts.Id = 0;
            this.barButtonItemContacts.Name = "barButtonItemContacts";
            // 
            // barButtonItemStores
            // 
            this.barButtonItemStores.Caption = "Stores";
            this.barButtonItemStores.Id = 1;
            this.barButtonItemStores.Name = "barButtonItemStores";
            // 
            // chartControl
            // 
            this.chartControl.AppearanceNameSerializable = "In A Fog";
            this.chartControl.BorderOptions.Visibility = DevExpress.Utils.DefaultBoolean.False;
            this.chartControl.Legend.AlignmentHorizontal = DevExpress.XtraCharts.LegendAlignmentHorizontal.Center;
            this.chartControl.Legend.AlignmentVertical = DevExpress.XtraCharts.LegendAlignmentVertical.BottomOutside;
            this.chartControl.Legend.Antialiasing = true;
            this.chartControl.Legend.BackColor = System.Drawing.Color.Transparent;
            this.chartControl.Legend.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.chartControl.Legend.Direction = DevExpress.XtraCharts.LegendDirection.LeftToRight;
            this.chartControl.Legend.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.chartControl.Location = new System.Drawing.Point(673, 93);
            this.chartControl.Name = "chartControl";
            this.chartControl.OptionsPrint.SizeMode = DevExpress.XtraCharts.Printing.PrintSizeMode.Zoom;
            this.chartControl.PaletteName = "Palette 1";
            this.chartControl.PaletteRepository.Add("Palette 1", new DevExpress.XtraCharts.Palette("Palette 1", DevExpress.XtraCharts.PaletteScaleMode.Repeat, new DevExpress.XtraCharts.PaletteEntry[] {
                new DevExpress.XtraCharts.PaletteEntry(System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(133)))), ((int)(((byte)(156))))), System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(133)))), ((int)(((byte)(156)))))),
                new DevExpress.XtraCharts.PaletteEntry(System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(113)))), ((int)(((byte)(0))))), System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(113)))), ((int)(((byte)(0)))))),
                new DevExpress.XtraCharts.PaletteEntry(System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(114)))), ((int)(((byte)(198))))), System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(114)))), ((int)(((byte)(198)))))),
                new DevExpress.XtraCharts.PaletteEntry(System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(113)))), ((int)(((byte)(56))))), System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(113)))), ((int)(((byte)(56)))))),
                new DevExpress.XtraCharts.PaletteEntry(System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(85)))), ((int)(((byte)(85))))), System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(85)))), ((int)(((byte)(85))))))}));
            doughnutSeriesLabel1.Antialiasing = true;
            doughnutSeriesLabel1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            doughnutSeriesLabel1.Position = DevExpress.XtraCharts.PieSeriesLabelPosition.Inside;
            doughnutSeriesLabel1.TextPattern = "${V:n}";
            series1.Label = doughnutSeriesLabel1;
            series1.LegendTextPattern = "{A}";
            series1.Name = "Series 1";
            doughnutSeriesView1.HoleRadiusPercent = 56;
            series1.View = doughnutSeriesView1;
            this.chartControl.SeriesSerializable = new DevExpress.XtraCharts.Series[] {
        series1};
            this.chartControl.SeriesTemplate.View = doughnutSeriesView2;
            this.chartControl.Size = new System.Drawing.Size(240, 352);
            this.chartControl.TabIndex = 4;
            this.chartControl.CustomDrawSeriesPoint += new DevExpress.XtraCharts.CustomDrawSeriesPointEventHandler(this.chartControl_CustomDrawSeriesPoint);
            // 
            // layoutControlGroup1
            // 
            this.layoutControlGroup1.CustomizationFormText = "Root";
            this.layoutControlGroup1.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.layoutControlGroup1.GroupBordersVisible = false;
            this.layoutControlGroup1.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem1,
            this.salesSLI,
            this.buttonHide,
            this.layoutControlItem2,
            this.lcgChart});
            this.layoutControlGroup1.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup1.Name = "Root";
            this.layoutControlGroup1.Padding = new DevExpress.XtraLayout.Utils.Padding(40, 40, 0, 0);
            this.layoutControlGroup1.Size = new System.Drawing.Size(955, 554);
            this.layoutControlGroup1.TextVisible = false;
            // 
            // layoutControlItem1
            // 
            this.layoutControlItem1.Control = this.salesGridControl;
            this.layoutControlItem1.CustomizationFormText = "layoutControlItem1";
            this.layoutControlItem1.Location = new System.Drawing.Point(0, 45);
            this.layoutControlItem1.Name = "layoutControlItem1";
            this.layoutControlItem1.Size = new System.Drawing.Size(603, 343);
            this.layoutControlItem1.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem1.TextVisible = false;
            // 
            // salesSLI
            // 
            this.salesSLI.AllowHotTrack = false;
            this.salesSLI.AllowHtmlStringInCaption = true;
            this.salesSLI.AppearanceItemCaption.FontSizeDelta = 3;
            this.salesSLI.AppearanceItemCaption.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(82)))), ((int)(((byte)(163)))));
            this.salesSLI.AppearanceItemCaption.Options.UseFont = true;
            this.salesSLI.AppearanceItemCaption.Options.UseForeColor = true;
            this.salesSLI.CustomizationFormText = " sales";
            this.salesSLI.Location = new System.Drawing.Point(0, 0);
            this.salesSLI.Name = " salesSLI";
            this.salesSLI.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 2, 10, 10);
            this.salesSLI.Size = new System.Drawing.Size(875, 45);
            this.salesSLI.Text = "SALES";
            this.salesSLI.TextSize = new System.Drawing.Size(51, 25);
            // 
            // buttonHide
            // 
            this.buttonHide.AllowHotTrack = false;
            this.buttonHide.CustomizationFormText = " ";
            this.buttonHide.Image = ((System.Drawing.Image)(resources.GetObject("buttonHide.Image")));
            this.buttonHide.Location = new System.Drawing.Point(603, 45);
            this.buttonHide.MaxSize = new System.Drawing.Size(28, 0);
            this.buttonHide.MinSize = new System.Drawing.Size(28, 1);
            this.buttonHide.Name = "buttonHide";
            this.buttonHide.Size = new System.Drawing.Size(28, 509);
            this.buttonHide.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.buttonHide.Text = " ";
            this.buttonHide.TextSize = new System.Drawing.Size(51, 25);
            this.buttonHide.Click += new System.EventHandler(this.collapseButton_Click);
            // 
            // layoutControlItem2
            // 
            this.layoutControlItem2.Control = this.rangeControl;
            this.layoutControlItem2.CustomizationFormText = "layoutControlItem2";
            this.layoutControlItem2.Location = new System.Drawing.Point(0, 388);
            this.layoutControlItem2.Name = "layoutControlItem2";
            this.layoutControlItem2.OptionsPrint.AllowPrint = false;
            this.layoutControlItem2.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 2, 26, 2);
            this.layoutControlItem2.Size = new System.Drawing.Size(603, 166);
            this.layoutControlItem2.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem2.TextVisible = false;
            // 
            // lcgChart
            // 
            this.lcgChart.CustomizationFormText = "lcgChart";
            this.lcgChart.GroupBordersVisible = false;
            this.lcgChart.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.lcSales,
            this.chartControlLCI,
            this.emptySpaceItem});
            this.lcgChart.Location = new System.Drawing.Point(631, 45);
            this.lcgChart.Name = "lcgChart";
            this.lcgChart.Size = new System.Drawing.Size(244, 509);
            this.lcgChart.Spacing = new DevExpress.XtraLayout.Utils.Padding(0, 0, 0, 0);
            // 
            // lcSales
            // 
            this.lcSales.Control = this.dropDownButton1;
            this.lcSales.ControlAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.lcSales.CustomizationFormText = "lcSales";
            this.lcSales.FillControlToClientArea = false;
            this.lcSales.Location = new System.Drawing.Point(0, 0);
            this.lcSales.MaxSize = new System.Drawing.Size(0, 46);
            this.lcSales.MinSize = new System.Drawing.Size(112, 46);
            this.lcSales.Name = "lcSales";
            this.lcSales.Size = new System.Drawing.Size(244, 46);
            this.lcSales.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.lcSales.TextSize = new System.Drawing.Size(0, 0);
            this.lcSales.TextVisible = false;
            this.lcSales.TrimClientAreaToControl = false;
            // 
            // chartControlLCI
            // 
            this.chartControlLCI.Control = this.chartControl;
            this.chartControlLCI.CustomizationFormText = "chartControlLCI";
            this.chartControlLCI.Location = new System.Drawing.Point(0, 46);
            this.chartControlLCI.Name = "chartControlLCI";
            this.chartControlLCI.Size = new System.Drawing.Size(244, 356);
            this.chartControlLCI.TextSize = new System.Drawing.Size(0, 0);
            this.chartControlLCI.TextVisible = false;
            // 
            // emptySpaceItem
            // 
            this.emptySpaceItem.AllowHotTrack = false;
            this.emptySpaceItem.CustomizationFormText = "emptySpaceItem";
            this.emptySpaceItem.Location = new System.Drawing.Point(0, 402);
            this.emptySpaceItem.Name = "emptySpaceItem";
            this.emptySpaceItem.Size = new System.Drawing.Size(244, 107);
            this.emptySpaceItem.TextSize = new System.Drawing.Size(0, 0);
            // 
            // simpleLabelItem7
            // 
            this.simpleLabelItem7.AllowHotTrack = false;
            this.simpleLabelItem7.AppearanceItemCaption.FontSizeDelta = 5;
            this.simpleLabelItem7.AppearanceItemCaption.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(82)))), ((int)(((byte)(163)))));
            this.simpleLabelItem7.AppearanceItemCaption.Options.UseFont = true;
            this.simpleLabelItem7.AppearanceItemCaption.Options.UseForeColor = true;
            this.simpleLabelItem7.CustomizationFormText = "Status";
            this.simpleLabelItem7.Location = new System.Drawing.Point(151, 0);
            this.simpleLabelItem7.Name = "simpleLabelItem1";
            this.simpleLabelItem7.Size = new System.Drawing.Size(830, 34);
            this.simpleLabelItem7.Text = "Status";
            this.simpleLabelItem7.TextSize = new System.Drawing.Size(127, 30);
            // 
            // simpleLabelItem4
            // 
            this.simpleLabelItem4.AllowHotTrack = false;
            this.simpleLabelItem4.AppearanceItemCaption.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.simpleLabelItem4.CustomizationFormText = " ";
            this.simpleLabelItem4.Image = ((System.Drawing.Image)(resources.GetObject("simpleLabelItem4.Image")));
            this.simpleLabelItem4.ImageAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.simpleLabelItem4.Location = new System.Drawing.Point(200, 34);
            this.simpleLabelItem4.MaxSize = new System.Drawing.Size(28, 0);
            this.simpleLabelItem4.MinSize = new System.Drawing.Size(28, 17);
            this.simpleLabelItem4.Name = "buttonHide";
            this.simpleLabelItem4.Size = new System.Drawing.Size(28, 512);
            this.simpleLabelItem4.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.simpleLabelItem4.Text = " ";
            this.simpleLabelItem4.TextSize = new System.Drawing.Size(127, 13);
            // 
            // simpleLabelItem3
            // 
            this.simpleLabelItem3.AllowHotTrack = false;
            this.simpleLabelItem3.AppearanceItemCaption.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.simpleLabelItem3.CustomizationFormText = " ";
            this.simpleLabelItem3.Image = ((System.Drawing.Image)(resources.GetObject("simpleLabelItem3.Image")));
            this.simpleLabelItem3.ImageAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.simpleLabelItem3.Location = new System.Drawing.Point(200, 34);
            this.simpleLabelItem3.MaxSize = new System.Drawing.Size(28, 0);
            this.simpleLabelItem3.MinSize = new System.Drawing.Size(28, 17);
            this.simpleLabelItem3.Name = "buttonHide";
            this.simpleLabelItem3.Size = new System.Drawing.Size(28, 512);
            this.simpleLabelItem3.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.simpleLabelItem3.Text = " ";
            this.simpleLabelItem3.TextSize = new System.Drawing.Size(127, 13);
            // 
            // simpleLabelItem2
            // 
            this.simpleLabelItem2.AllowHotTrack = false;
            this.simpleLabelItem2.AppearanceItemCaption.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.simpleLabelItem2.CustomizationFormText = " ";
            this.simpleLabelItem2.Image = ((System.Drawing.Image)(resources.GetObject("simpleLabelItem2.Image")));
            this.simpleLabelItem2.ImageAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.simpleLabelItem2.Location = new System.Drawing.Point(200, 34);
            this.simpleLabelItem2.MaxSize = new System.Drawing.Size(28, 0);
            this.simpleLabelItem2.MinSize = new System.Drawing.Size(28, 17);
            this.simpleLabelItem2.Name = "buttonHide";
            this.simpleLabelItem2.Size = new System.Drawing.Size(28, 512);
            this.simpleLabelItem2.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.simpleLabelItem2.Text = " ";
            this.simpleLabelItem2.TextSize = new System.Drawing.Size(127, 13);
            // 
            // simpleLabelItem1
            // 
            this.simpleLabelItem1.AllowHotTrack = false;
            this.simpleLabelItem1.AppearanceItemCaption.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.simpleLabelItem1.CustomizationFormText = " ";
            this.simpleLabelItem1.Image = ((System.Drawing.Image)(resources.GetObject("simpleLabelItem1.Image")));
            this.simpleLabelItem1.ImageAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.simpleLabelItem1.Location = new System.Drawing.Point(200, 34);
            this.simpleLabelItem1.MaxSize = new System.Drawing.Size(28, 0);
            this.simpleLabelItem1.MinSize = new System.Drawing.Size(28, 17);
            this.simpleLabelItem1.Name = "buttonHide";
            this.simpleLabelItem1.Size = new System.Drawing.Size(28, 512);
            this.simpleLabelItem1.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.simpleLabelItem1.Text = " ";
            this.simpleLabelItem1.TextSize = new System.Drawing.Size(127, 13);
            // 
            // simpleLabelItem5
            // 
            this.simpleLabelItem5.AllowHotTrack = false;
            this.simpleLabelItem5.AppearanceItemCaption.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.simpleLabelItem5.CustomizationFormText = " ";
            this.simpleLabelItem5.Image = ((System.Drawing.Image)(resources.GetObject("simpleLabelItem5.Image")));
            this.simpleLabelItem5.ImageAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.simpleLabelItem5.Location = new System.Drawing.Point(200, 34);
            this.simpleLabelItem5.MaxSize = new System.Drawing.Size(28, 0);
            this.simpleLabelItem5.MinSize = new System.Drawing.Size(28, 17);
            this.simpleLabelItem5.Name = "buttonHide";
            this.simpleLabelItem5.Size = new System.Drawing.Size(28, 512);
            this.simpleLabelItem5.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.simpleLabelItem5.Text = " ";
            this.simpleLabelItem5.TextSize = new System.Drawing.Size(127, 13);
            // 
            // tileItemHighPriority
            // 
            tileItemElement1.Appearance.Hovered.FontSizeDelta = 10;
            tileItemElement1.Appearance.Hovered.Options.UseFont = true;
            tileItemElement1.Appearance.Hovered.Options.UseTextOptions = true;
            tileItemElement1.Appearance.Hovered.TextOptions.Trimming = DevExpress.Utils.Trimming.Character;
            tileItemElement1.Appearance.Normal.FontSizeDelta = 10;
            tileItemElement1.Appearance.Normal.Options.UseFont = true;
            tileItemElement1.Appearance.Normal.Options.UseTextOptions = true;
            tileItemElement1.Appearance.Normal.TextOptions.Trimming = DevExpress.Utils.Trimming.Character;
            tileItemElement1.Appearance.Selected.FontSizeDelta = 10;
            tileItemElement1.Appearance.Selected.Options.UseFont = true;
            tileItemElement1.Appearance.Selected.Options.UseTextOptions = true;
            tileItemElement1.Appearance.Selected.TextOptions.Trimming = DevExpress.Utils.Trimming.Character;
            tileItemElement1.ImageAlignment = DevExpress.XtraEditors.TileItemContentAlignment.Manual;
            tileItemElement1.ImageLocation = new System.Drawing.Point(-6, -4);
            tileItemElement1.MaxWidth = 55;
            tileItemElement1.Text = "5";
            tileItemElement1.TextAlignment = DevExpress.XtraEditors.TileItemContentAlignment.TopRight;
            tileItemElement1.TextLocation = new System.Drawing.Point(-6, -11);
            tileItemElement2.ImageAlignment = DevExpress.XtraEditors.TileItemContentAlignment.TopLeft;
            tileItemElement2.Text = "High Priority";
            tileItemElement2.TextAlignment = DevExpress.XtraEditors.TileItemContentAlignment.BottomRight;
            this.tileItemHighPriority.Elements.Add(tileItemElement1);
            this.tileItemHighPriority.Elements.Add(tileItemElement2);
            this.tileItemHighPriority.Id = 6;
            this.tileItemHighPriority.ItemSize = DevExpress.XtraEditors.TileItemSize.Wide;
            this.tileItemHighPriority.Name = "tileItemHighPriority";
            this.tileItemHighPriority.Tag = "Priority == \'High\'";
            // 
            // tileItemUrgent
            // 
            tileItemElement3.Appearance.Hovered.FontSizeDelta = 15;
            tileItemElement3.Appearance.Hovered.Options.UseFont = true;
            tileItemElement3.Appearance.Hovered.Options.UseTextOptions = true;
            tileItemElement3.Appearance.Hovered.TextOptions.Trimming = DevExpress.Utils.Trimming.Character;
            tileItemElement3.Appearance.Normal.FontSizeDelta = 15;
            tileItemElement3.Appearance.Normal.Options.UseFont = true;
            tileItemElement3.Appearance.Normal.Options.UseTextOptions = true;
            tileItemElement3.Appearance.Normal.TextOptions.Trimming = DevExpress.Utils.Trimming.Character;
            tileItemElement3.Appearance.Selected.FontSizeDelta = 15;
            tileItemElement3.Appearance.Selected.Options.UseFont = true;
            tileItemElement3.Appearance.Selected.Options.UseTextOptions = true;
            tileItemElement3.Appearance.Selected.TextOptions.Trimming = DevExpress.Utils.Trimming.Character;
            tileItemElement3.ImageAlignment = DevExpress.XtraEditors.TileItemContentAlignment.Manual;
            tileItemElement3.ImageLocation = new System.Drawing.Point(-5, -3);
            tileItemElement3.MaxWidth = 63;
            tileItemElement3.Text = "5";
            tileItemElement3.TextAlignment = DevExpress.XtraEditors.TileItemContentAlignment.TopRight;
            tileItemElement3.TextLocation = new System.Drawing.Point(-5, -12);
            tileItemElement4.ImageAlignment = DevExpress.XtraEditors.TileItemContentAlignment.TopLeft;
            tileItemElement4.Text = "Urgent";
            tileItemElement4.TextAlignment = DevExpress.XtraEditors.TileItemContentAlignment.BottomRight;
            this.tileItemUrgent.Elements.Add(tileItemElement3);
            this.tileItemUrgent.Elements.Add(tileItemElement4);
            this.tileItemUrgent.Id = 5;
            this.tileItemUrgent.ItemSize = DevExpress.XtraEditors.TileItemSize.Wide;
            this.tileItemUrgent.Name = "tileItemUrgent";
            this.tileItemUrgent.Tag = "Priority == \'Urgent\'";
            // 
            // tileItemCompleted
            // 
            tileItemElement5.Appearance.Hovered.FontSizeDelta = 15;
            tileItemElement5.Appearance.Hovered.Options.UseFont = true;
            tileItemElement5.Appearance.Hovered.Options.UseTextOptions = true;
            tileItemElement5.Appearance.Hovered.TextOptions.Trimming = DevExpress.Utils.Trimming.Character;
            tileItemElement5.Appearance.Normal.FontSizeDelta = 15;
            tileItemElement5.Appearance.Normal.Options.UseFont = true;
            tileItemElement5.Appearance.Normal.Options.UseTextOptions = true;
            tileItemElement5.Appearance.Normal.TextOptions.Trimming = DevExpress.Utils.Trimming.Character;
            tileItemElement5.Appearance.Selected.FontSizeDelta = 15;
            tileItemElement5.Appearance.Selected.Options.UseFont = true;
            tileItemElement5.Appearance.Selected.Options.UseTextOptions = true;
            tileItemElement5.Appearance.Selected.TextOptions.Trimming = DevExpress.Utils.Trimming.Character;
            tileItemElement5.ImageAlignment = DevExpress.XtraEditors.TileItemContentAlignment.Manual;
            tileItemElement5.ImageLocation = new System.Drawing.Point(-5, -3);
            tileItemElement5.MaxWidth = 63;
            tileItemElement5.Text = "5";
            tileItemElement5.TextAlignment = DevExpress.XtraEditors.TileItemContentAlignment.TopRight;
            tileItemElement5.TextLocation = new System.Drawing.Point(-5, -12);
            tileItemElement6.ImageAlignment = DevExpress.XtraEditors.TileItemContentAlignment.TopLeft;
            tileItemElement6.Text = "Completed";
            tileItemElement6.TextAlignment = DevExpress.XtraEditors.TileItemContentAlignment.BottomRight;
            this.tileItemCompleted.Elements.Add(tileItemElement5);
            this.tileItemCompleted.Elements.Add(tileItemElement6);
            this.tileItemCompleted.Id = 4;
            this.tileItemCompleted.ItemSize = DevExpress.XtraEditors.TileItemSize.Wide;
            this.tileItemCompleted.Name = "tileItemCompleted";
            this.tileItemCompleted.Tag = "Status == \'Completed\'";
            // 
            // tileItemDeferred
            // 
            tileItemElement7.Appearance.Hovered.FontSizeDelta = 15;
            tileItemElement7.Appearance.Hovered.Options.UseFont = true;
            tileItemElement7.Appearance.Hovered.Options.UseTextOptions = true;
            tileItemElement7.Appearance.Hovered.TextOptions.Trimming = DevExpress.Utils.Trimming.Character;
            tileItemElement7.Appearance.Normal.FontSizeDelta = 15;
            tileItemElement7.Appearance.Normal.Options.UseFont = true;
            tileItemElement7.Appearance.Normal.Options.UseTextOptions = true;
            tileItemElement7.Appearance.Normal.TextOptions.Trimming = DevExpress.Utils.Trimming.Character;
            tileItemElement7.Appearance.Selected.FontSizeDelta = 15;
            tileItemElement7.Appearance.Selected.Options.UseFont = true;
            tileItemElement7.Appearance.Selected.Options.UseTextOptions = true;
            tileItemElement7.Appearance.Selected.TextOptions.Trimming = DevExpress.Utils.Trimming.Character;
            tileItemElement7.ImageAlignment = DevExpress.XtraEditors.TileItemContentAlignment.Manual;
            tileItemElement7.ImageLocation = new System.Drawing.Point(-5, -3);
            tileItemElement7.MaxWidth = 63;
            tileItemElement7.Text = "5";
            tileItemElement7.TextAlignment = DevExpress.XtraEditors.TileItemContentAlignment.TopRight;
            tileItemElement7.TextLocation = new System.Drawing.Point(-5, -12);
            tileItemElement8.ImageAlignment = DevExpress.XtraEditors.TileItemContentAlignment.TopLeft;
            tileItemElement8.Text = "Deferred";
            tileItemElement8.TextAlignment = DevExpress.XtraEditors.TileItemContentAlignment.BottomRight;
            this.tileItemDeferred.Elements.Add(tileItemElement7);
            this.tileItemDeferred.Elements.Add(tileItemElement8);
            this.tileItemDeferred.Id = 3;
            this.tileItemDeferred.ItemSize = DevExpress.XtraEditors.TileItemSize.Wide;
            this.tileItemDeferred.Name = "tileItemDeferred";
            this.tileItemDeferred.Tag = "Status = \'Deferred\'";
            // 
            // tileItemNotStartedTask
            // 
            tileItemElement9.Appearance.Hovered.FontSizeDelta = 15;
            tileItemElement9.Appearance.Hovered.Options.UseFont = true;
            tileItemElement9.Appearance.Hovered.Options.UseTextOptions = true;
            tileItemElement9.Appearance.Hovered.TextOptions.Trimming = DevExpress.Utils.Trimming.Character;
            tileItemElement9.Appearance.Normal.FontSizeDelta = 15;
            tileItemElement9.Appearance.Normal.Options.UseFont = true;
            tileItemElement9.Appearance.Normal.Options.UseTextOptions = true;
            tileItemElement9.Appearance.Normal.TextOptions.Trimming = DevExpress.Utils.Trimming.Character;
            tileItemElement9.Appearance.Selected.FontSizeDelta = 15;
            tileItemElement9.Appearance.Selected.Options.UseFont = true;
            tileItemElement9.Appearance.Selected.Options.UseTextOptions = true;
            tileItemElement9.Appearance.Selected.TextOptions.Trimming = DevExpress.Utils.Trimming.Character;
            tileItemElement9.ImageAlignment = DevExpress.XtraEditors.TileItemContentAlignment.Manual;
            tileItemElement9.ImageLocation = new System.Drawing.Point(-5, -3);
            tileItemElement9.MaxWidth = 63;
            tileItemElement9.Text = "5";
            tileItemElement9.TextAlignment = DevExpress.XtraEditors.TileItemContentAlignment.TopRight;
            tileItemElement9.TextLocation = new System.Drawing.Point(-5, -12);
            tileItemElement10.ImageAlignment = DevExpress.XtraEditors.TileItemContentAlignment.TopLeft;
            tileItemElement10.Text = "Not Started";
            tileItemElement10.TextAlignment = DevExpress.XtraEditors.TileItemContentAlignment.BottomRight;
            this.tileItemNotStartedTask.Elements.Add(tileItemElement9);
            this.tileItemNotStartedTask.Elements.Add(tileItemElement10);
            this.tileItemNotStartedTask.Id = 2;
            this.tileItemNotStartedTask.ItemSize = DevExpress.XtraEditors.TileItemSize.Wide;
            this.tileItemNotStartedTask.Name = "tileItemNotStartedTask";
            this.tileItemNotStartedTask.Tag = "Status == \'NotStarted\'";
            // 
            // tileItemInProgress
            // 
            tileItemElement11.Appearance.Hovered.FontSizeDelta = 15;
            tileItemElement11.Appearance.Hovered.Options.UseFont = true;
            tileItemElement11.Appearance.Hovered.Options.UseTextOptions = true;
            tileItemElement11.Appearance.Hovered.TextOptions.Trimming = DevExpress.Utils.Trimming.Character;
            tileItemElement11.Appearance.Normal.FontSizeDelta = 15;
            tileItemElement11.Appearance.Normal.Options.UseFont = true;
            tileItemElement11.Appearance.Normal.Options.UseTextOptions = true;
            tileItemElement11.Appearance.Normal.TextOptions.Trimming = DevExpress.Utils.Trimming.Character;
            tileItemElement11.Appearance.Selected.FontSizeDelta = 15;
            tileItemElement11.Appearance.Selected.Options.UseFont = true;
            tileItemElement11.Appearance.Selected.Options.UseTextOptions = true;
            tileItemElement11.Appearance.Selected.TextOptions.Trimming = DevExpress.Utils.Trimming.Character;
            tileItemElement11.ImageAlignment = DevExpress.XtraEditors.TileItemContentAlignment.Manual;
            tileItemElement11.ImageLocation = new System.Drawing.Point(-5, -3);
            tileItemElement11.MaxWidth = 63;
            tileItemElement11.Text = "5";
            tileItemElement11.TextAlignment = DevExpress.XtraEditors.TileItemContentAlignment.TopRight;
            tileItemElement11.TextLocation = new System.Drawing.Point(-5, -12);
            tileItemElement12.ImageAlignment = DevExpress.XtraEditors.TileItemContentAlignment.TopLeft;
            tileItemElement12.Text = "In Progress";
            tileItemElement12.TextAlignment = DevExpress.XtraEditors.TileItemContentAlignment.BottomRight;
            this.tileItemInProgress.Elements.Add(tileItemElement11);
            this.tileItemInProgress.Elements.Add(tileItemElement12);
            this.tileItemInProgress.Id = 1;
            this.tileItemInProgress.ItemSize = DevExpress.XtraEditors.TileItemSize.Wide;
            this.tileItemInProgress.Name = "tileItemInProgress";
            this.tileItemInProgress.Tag = "Status == \'InProgress\'";
            // 
            // tileItemAll
            // 
            tileItemElement13.Appearance.Hovered.FontSizeDelta = 15;
            tileItemElement13.Appearance.Hovered.Options.UseFont = true;
            tileItemElement13.Appearance.Hovered.Options.UseTextOptions = true;
            tileItemElement13.Appearance.Hovered.TextOptions.Trimming = DevExpress.Utils.Trimming.Character;
            tileItemElement13.Appearance.Normal.FontSizeDelta = 15;
            tileItemElement13.Appearance.Normal.Options.UseFont = true;
            tileItemElement13.Appearance.Normal.Options.UseTextOptions = true;
            tileItemElement13.Appearance.Normal.TextOptions.Trimming = DevExpress.Utils.Trimming.Character;
            tileItemElement13.Appearance.Selected.FontSizeDelta = 15;
            tileItemElement13.Appearance.Selected.Options.UseFont = true;
            tileItemElement13.Appearance.Selected.Options.UseTextOptions = true;
            tileItemElement13.Appearance.Selected.TextOptions.Trimming = DevExpress.Utils.Trimming.Character;
            tileItemElement13.ImageAlignment = DevExpress.XtraEditors.TileItemContentAlignment.Manual;
            tileItemElement13.ImageLocation = new System.Drawing.Point(-5, -3);
            tileItemElement13.MaxWidth = 63;
            tileItemElement13.Text = "183";
            tileItemElement13.TextAlignment = DevExpress.XtraEditors.TileItemContentAlignment.TopRight;
            tileItemElement13.TextLocation = new System.Drawing.Point(-5, -12);
            tileItemElement14.ImageAlignment = DevExpress.XtraEditors.TileItemContentAlignment.TopLeft;
            tileItemElement14.Text = "All  sales";
            tileItemElement14.TextAlignment = DevExpress.XtraEditors.TileItemContentAlignment.BottomRight;
            this.tileItemAll.Elements.Add(tileItemElement13);
            this.tileItemAll.Elements.Add(tileItemElement14);
            this.tileItemAll.Id = 0;
            this.tileItemAll.ItemSize = DevExpress.XtraEditors.TileItemSize.Wide;
            this.tileItemAll.Name = "tileItemAll";
            this.tileItemAll.Tag = "Priority != \'null\'";
            // 
            // commandBarGalleryDropDown1
            // 
            // 
            // 
            // 
            createBarChartItem1.Caption = "Clustered Column";
            createBarChartItem1.Description = "Compare values across categories by using vertical rectangles.\r\n\r\nUse it when the" +
    " order of categories is not important or for displaying item counts such as a hi" +
    "stogram.\r\n    ";
            createBarChartItem1.Hint = "Compare values across categories by using vertical rectangles.\r\n\r\nUse it when the" +
    " order of categories is not important or for displaying item counts such as a hi" +
    "stogram.\r\n    ";
            createFullStackedBarChartItem1.Caption = "100% Stacked Column";
            createFullStackedBarChartItem1.Description = "Compare the percentage that each value contributes to a total across categories b" +
    "y using vertical rectangles.\r\n\r\nUse it to emphasize the proportion of each data " +
    "series.\r\n    ";
            createFullStackedBarChartItem1.Hint = "Compare the percentage that each value contributes to a total across categories b" +
    "y using vertical rectangles.\r\n\r\nUse it to emphasize the proportion of each data " +
    "series.\r\n    ";
            createSideBySideFullStackedBarChartItem1.Caption = "Clustered 100% Stacked Column";
            createSideBySideFullStackedBarChartItem1.Description = "Combine the advantages of both the 100% Stacked Column and Clustered Column chart" +
    " types, so that you can stack different columns, and combine them into groups ac" +
    "ross the same axis value.";
            createSideBySideFullStackedBarChartItem1.Hint = "Combine the advantages of both the 100% Stacked Column and Clustered Column chart" +
    " types, so that you can stack different columns, and combine them into groups ac" +
    "ross the same axis value.";
            createSideBySideStackedBarChartItem1.Caption = "Clustered Stacked Column";
            createSideBySideStackedBarChartItem1.Description = "Combine the advantages of both the Stacked Column and Clustered Column chart type" +
    "s, so that you can stack different columns, and combine them into groups across " +
    "the same axis value.";
            createSideBySideStackedBarChartItem1.Hint = "Combine the advantages of both the Stacked Column and Clustered Column chart type" +
    "s, so that you can stack different columns, and combine them into groups across " +
    "the same axis value.";
            createStackedBarChartItem1.Caption = "Stacked Column";
            createStackedBarChartItem1.Description = "Compare the contribution of each value to a total across categories by using vert" +
    "ical rectangles.\r\n\r\nUse it to emphasize the total across series for one category" +
    ".\r\n    ";
            createStackedBarChartItem1.Hint = "Compare the contribution of each value to a total across categories by using vert" +
    "ical rectangles.\r\n\r\nUse it to emphasize the total across series for one category" +
    ".\r\n    ";
            chartControlCommandGalleryItemGroup2DColumn1.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            createBarChartItem1,
            createFullStackedBarChartItem1,
            createSideBySideFullStackedBarChartItem1,
            createSideBySideStackedBarChartItem1,
            createStackedBarChartItem1});
            createBar3DChartItem1.Caption = "3-D Clustered Column";
            createBar3DChartItem1.Description = "Compare values across categories and display clustered columns in 3-D format.";
            createBar3DChartItem1.Hint = "Compare values across categories and display clustered columns in 3-D format.";
            createFullStackedBar3DChartItem1.Caption = "100% Stacked Column in 3-D";
            createFullStackedBar3DChartItem1.Description = "Compare the percentage each value contributes to a total across categories and di" +
    "splay 100% stacked columns in 3-D format.";
            createFullStackedBar3DChartItem1.Hint = "Compare the percentage each value contributes to a total across categories and di" +
    "splay 100% stacked columns in 3-D format.";
            createManhattanBarChartItem1.Caption = "3-D Column";
            createManhattanBarChartItem1.Description = "Compare values across categories and across series on three axes.\r\n\r\nUse it when " +
    "the categories and series are equally important.\r\n    ";
            createManhattanBarChartItem1.Hint = "Compare values across categories and across series on three axes.\r\n\r\nUse it when " +
    "the categories and series are equally important.\r\n    ";
            createSideBySideFullStackedBar3DChartItem1.Caption = "Clustered 100% Stacked Column in 3-D";
            createSideBySideFullStackedBar3DChartItem1.Description = "Combine the advantages of both the 100% Stacked Column and Clustered Column chart" +
    " types in 3-D format, so that you can stack different columns, and combine them " +
    "into groups across the same axis value.";
            createSideBySideFullStackedBar3DChartItem1.Hint = "Combine the advantages of both the 100% Stacked Column and Clustered Column chart" +
    " types in 3-D format, so that you can stack different columns, and combine them " +
    "into groups across the same axis value.";
            createSideBySideStackedBar3DChartItem1.Caption = "Clustered Stacked Column in 3-D";
            createSideBySideStackedBar3DChartItem1.Description = "Combine the advantages of both the Stacked Column and Clustered Column chart type" +
    "s in 3-D format, so that you can stack different columns, and combine them into " +
    "groups across the same axis value.";
            createSideBySideStackedBar3DChartItem1.Hint = "Combine the advantages of both the Stacked Column and Clustered Column chart type" +
    "s in 3-D format, so that you can stack different columns, and combine them into " +
    "groups across the same axis value.";
            createStackedBar3DChartItem1.Caption = "Stacked Column in 3-D";
            createStackedBar3DChartItem1.Description = "Compare the contribution of each value to a total across categories and display s" +
    "tacked columns in 3-D format.";
            createStackedBar3DChartItem1.Hint = "Compare the contribution of each value to a total across categories and display s" +
    "tacked columns in 3-D format.";
            chartControlCommandGalleryItemGroup3DColumn1.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            createBar3DChartItem1,
            createFullStackedBar3DChartItem1,
            createManhattanBarChartItem1,
            createSideBySideFullStackedBar3DChartItem1,
            createSideBySideStackedBar3DChartItem1,
            createStackedBar3DChartItem1});
            createCylinderBar3DChartItem1.Caption = "Clustered Cylinder";
            createCylinderBar3DChartItem1.Description = "Compare values across categories.";
            createCylinderBar3DChartItem1.Hint = "Compare values across categories.";
            createCylinderFullStackedBar3DChartItem1.Caption = "100% Stacked Cylinder";
            createCylinderFullStackedBar3DChartItem1.Description = "Compare the percentage each value contributes to a total across categories.";
            createCylinderFullStackedBar3DChartItem1.Hint = "Compare the percentage each value contributes to a total across categories.";
            createCylinderManhattanBarChartItem1.Caption = "3-D Cylinder";
            createCylinderManhattanBarChartItem1.Description = "Compare values across categories and across series and display a cylinder chart o" +
    "n three axes.";
            createCylinderManhattanBarChartItem1.Hint = "Compare values across categories and across series and display a cylinder chart o" +
    "n three axes.";
            createCylinderSideBySideFullStackedBar3DChartItem1.Caption = "Clustered 100% Stacked Cylinder";
            createCylinderSideBySideFullStackedBar3DChartItem1.Description = "Combine the advantages of both the 100% Stacked Cylinder and Clustered Cylinder c" +
    "hart types, so that you can stack different cylinders, and combine them into gro" +
    "ups across the same axis value.";
            createCylinderSideBySideFullStackedBar3DChartItem1.Hint = "Combine the advantages of both the 100% Stacked Cylinder and Clustered Cylinder c" +
    "hart types, so that you can stack different cylinders, and combine them into gro" +
    "ups across the same axis value.";
            createCylinderSideBySideStackedBar3DChartItem1.Caption = "Clustered Stacked Cylinder";
            createCylinderSideBySideStackedBar3DChartItem1.Description = "Combine the advantages of both the Stacked Cylinder and Clustered Cylinder chart " +
    "types, so that you can stack different cylinders, and combine them into groups a" +
    "cross the same axis value.";
            createCylinderSideBySideStackedBar3DChartItem1.Hint = "Combine the advantages of both the Stacked Cylinder and Clustered Cylinder chart " +
    "types, so that you can stack different cylinders, and combine them into groups a" +
    "cross the same axis value.";
            createCylinderStackedBar3DChartItem1.Caption = "Stacked Cylinder";
            createCylinderStackedBar3DChartItem1.Description = "Compare the contribution of each value to a total across categories.";
            createCylinderStackedBar3DChartItem1.Hint = "Compare the contribution of each value to a total across categories.";
            chartControlCommandGalleryItemGroupCylinderColumn1.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            createCylinderBar3DChartItem1,
            createCylinderFullStackedBar3DChartItem1,
            createCylinderManhattanBarChartItem1,
            createCylinderSideBySideFullStackedBar3DChartItem1,
            createCylinderSideBySideStackedBar3DChartItem1,
            createCylinderStackedBar3DChartItem1});
            createConeBar3DChartItem1.Caption = "Clustered Cone";
            createConeBar3DChartItem1.Description = "Compare values across categories.";
            createConeBar3DChartItem1.Hint = "Compare values across categories.";
            createConeFullStackedBar3DChartItem1.Caption = "100% Stacked Cone";
            createConeFullStackedBar3DChartItem1.Description = "Compare the percentage each value contributes to a total across categories.";
            createConeFullStackedBar3DChartItem1.Hint = "Compare the percentage each value contributes to a total across categories.";
            createConeManhattanBarChartItem1.Caption = "3-D Cone";
            createConeManhattanBarChartItem1.Description = "Compare values across categories and across series and display a cone chart on th" +
    "ree axes.";
            createConeManhattanBarChartItem1.Hint = "Compare values across categories and across series and display a cone chart on th" +
    "ree axes.";
            createConeSideBySideFullStackedBar3DChartItem1.Caption = "Clustered 100% Stacked Cone";
            createConeSideBySideFullStackedBar3DChartItem1.Description = "Combine the advantages of both the 100% Stacked Cone and Clustered Cone chart typ" +
    "es, so that you can stack different cones, and combine them into groups across t" +
    "he same axis value.";
            createConeSideBySideFullStackedBar3DChartItem1.Hint = "Combine the advantages of both the 100% Stacked Cone and Clustered Cone chart typ" +
    "es, so that you can stack different cones, and combine them into groups across t" +
    "he same axis value.";
            createConeSideBySideStackedBar3DChartItem1.Caption = "Clustered Stacked Cone";
            createConeSideBySideStackedBar3DChartItem1.Description = "Combine the advantages of both the Stacked Cone and Clustered Cone chart types, s" +
    "o that you can stack different cones, and combine them into groups across the sa" +
    "me axis value.";
            createConeSideBySideStackedBar3DChartItem1.Hint = "Combine the advantages of both the Stacked Cone and Clustered Cone chart types, s" +
    "o that you can stack different cones, and combine them into groups across the sa" +
    "me axis value.";
            createConeStackedBar3DChartItem1.Caption = "Stacked Cone";
            createConeStackedBar3DChartItem1.Description = "Compare the contribution of each value to a total across categories.";
            createConeStackedBar3DChartItem1.Hint = "Compare the contribution of each value to a total across categories.";
            chartControlCommandGalleryItemGroupConeColumn1.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            createConeBar3DChartItem1,
            createConeFullStackedBar3DChartItem1,
            createConeManhattanBarChartItem1,
            createConeSideBySideFullStackedBar3DChartItem1,
            createConeSideBySideStackedBar3DChartItem1,
            createConeStackedBar3DChartItem1});
            createPyramidBar3DChartItem1.Caption = "Clustered Pyramid";
            createPyramidBar3DChartItem1.Description = "Compare values across categories.";
            createPyramidBar3DChartItem1.Hint = "Compare values across categories.";
            createPyramidFullStackedBar3DChartItem1.Caption = "100% Stacked Pyramid";
            createPyramidFullStackedBar3DChartItem1.Description = "Compare the percentage each value contributes to a total across categories.";
            createPyramidFullStackedBar3DChartItem1.Hint = "Compare the percentage each value contributes to a total across categories.";
            createPyramidManhattanBarChartItem1.Caption = "3-D Pyramid";
            createPyramidManhattanBarChartItem1.Description = "Compare values across categories and across series and display a pyramid chart on" +
    " three axes.";
            createPyramidManhattanBarChartItem1.Hint = "Compare values across categories and across series and display a pyramid chart on" +
    " three axes.";
            createPyramidSideBySideFullStackedBar3DChartItem1.Caption = "Clustered 100% Stacked Pyramid";
            createPyramidSideBySideFullStackedBar3DChartItem1.Description = "Combine the advantages of both the 100% Stacked Pyramid and Clustered Pyramid cha" +
    "rt types, so that you can stack different pyramids, and combine them into groups" +
    " across the same axis value.";
            createPyramidSideBySideFullStackedBar3DChartItem1.Hint = "Combine the advantages of both the 100% Stacked Pyramid and Clustered Pyramid cha" +
    "rt types, so that you can stack different pyramids, and combine them into groups" +
    " across the same axis value.";
            createPyramidSideBySideStackedBar3DChartItem1.Caption = "Clustered Stacked Pyramid";
            createPyramidSideBySideStackedBar3DChartItem1.Description = "Combine the advantages of both the Stacked Pyramid and Clustered Pyramid chart ty" +
    "pes, so that you can stack different pyramids, and combine them into groups acro" +
    "ss the same axis value.";
            createPyramidSideBySideStackedBar3DChartItem1.Hint = "Combine the advantages of both the Stacked Pyramid and Clustered Pyramid chart ty" +
    "pes, so that you can stack different pyramids, and combine them into groups acro" +
    "ss the same axis value.";
            createPyramidStackedBar3DChartItem1.Caption = "Stacked Pyramid";
            createPyramidStackedBar3DChartItem1.Description = "Compare the contribution of each value to a total across categories.";
            createPyramidStackedBar3DChartItem1.Hint = "Compare the contribution of each value to a total across categories.";
            chartControlCommandGalleryItemGroupPyramidColumn1.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            createPyramidBar3DChartItem1,
            createPyramidFullStackedBar3DChartItem1,
            createPyramidManhattanBarChartItem1,
            createPyramidSideBySideFullStackedBar3DChartItem1,
            createPyramidSideBySideStackedBar3DChartItem1,
            createPyramidStackedBar3DChartItem1});
            this.commandBarGalleryDropDown1.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            chartControlCommandGalleryItemGroup2DColumn1,
            chartControlCommandGalleryItemGroup3DColumn1,
            chartControlCommandGalleryItemGroupCylinderColumn1,
            chartControlCommandGalleryItemGroupConeColumn1,
            chartControlCommandGalleryItemGroupPyramidColumn1});
            this.commandBarGalleryDropDown1.Manager = this.barManager1;
            this.commandBarGalleryDropDown1.Name = "commandBarGalleryDropDown1";
            this.commandBarGalleryDropDown1.ShowNavigationHeader = DevExpress.Utils.DefaultBoolean.True;
            // 
            // commandBarGalleryDropDown2
            // 
            // 
            // 
            // 
            createLineChartItem1.Caption = "Line";
            createLineChartItem1.Description = "Display trend overtime (dates, years) or ordered categories. Useful when there ar" +
    "e many data points and the order is important.";
            createLineChartItem1.Hint = "Display trend overtime (dates, years) or ordered categories. Useful when there ar" +
    "e many data points and the order is important.";
            createFullStackedLineChartItem1.Caption = "100% Stacked Line";
            createFullStackedLineChartItem1.Description = "Display the trend of the percentage each value contributes over time or ordered c" +
    "ategories.";
            createFullStackedLineChartItem1.Hint = "Display the trend of the percentage each value contributes over time or ordered c" +
    "ategories.";
            createScatterLineChartItem1.Caption = "Scatter Line";
            createScatterLineChartItem1.Description = "Represent series points in the same order that they have in the collection.";
            createScatterLineChartItem1.Hint = "Represent series points in the same order that they have in the collection.";
            createSplineChartItem1.Caption = "Spline";
            createSplineChartItem1.Description = "Plot a fitted curve through each data point in a series.";
            createSplineChartItem1.Hint = "Plot a fitted curve through each data point in a series.";
            createStackedLineChartItem1.Caption = "Stacked Line";
            createStackedLineChartItem1.Description = "Display the trend of the contribution of each value over time or ordered categori" +
    "es.";
            createStackedLineChartItem1.Hint = "Display the trend of the contribution of each value over time or ordered categori" +
    "es.";
            createStepLineChartItem1.Caption = "Step Line";
            createStepLineChartItem1.Description = "Show to what extent values have changed for different points in the same series.";
            createStepLineChartItem1.Hint = "Show to what extent values have changed for different points in the same series.";
            chartControlCommandGalleryItemGroup2DLine1.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            createLineChartItem1,
            createFullStackedLineChartItem1,
            createScatterLineChartItem1,
            createSplineChartItem1,
            createStackedLineChartItem1,
            createStepLineChartItem1});
            createLine3DChartItem1.Caption = "3-D Line";
            createLine3DChartItem1.Description = "Display each row or column of data as a 3-D ribbon on three axes.";
            createLine3DChartItem1.Hint = "Display each row or column of data as a 3-D ribbon on three axes.";
            createFullStackedLine3DChartItem1.Caption = "100% Stacked Line in 3-D";
            createFullStackedLine3DChartItem1.Description = "Display all series stacked and is useful when it is necessary to compare how much" +
    " each series adds to the total aggregate value for specific arguments (as percen" +
    "ts).";
            createFullStackedLine3DChartItem1.Hint = "Display all series stacked and is useful when it is necessary to compare how much" +
    " each series adds to the total aggregate value for specific arguments (as percen" +
    "ts).";
            createSpline3DChartItem1.Caption = "3-D Spline";
            createSpline3DChartItem1.Description = "Plot a fitted curve through each data point in a series.";
            createSpline3DChartItem1.Hint = "Plot a fitted curve through each data point in a series.";
            createStackedLine3DChartItem1.Caption = "Stacked Line in 3-D";
            createStackedLine3DChartItem1.Description = "Display all points from different series in a stacked manner and is useful when i" +
    "t is necessary to compare how much each series adds to the total aggregate value" +
    " for specific arguments.";
            createStackedLine3DChartItem1.Hint = "Display all points from different series in a stacked manner and is useful when i" +
    "t is necessary to compare how much each series adds to the total aggregate value" +
    " for specific arguments.";
            createStepLine3DChartItem1.Caption = "Step Line in 3-D";
            createStepLine3DChartItem1.Description = "Show to what extent values have changed for different points in the same series.";
            createStepLine3DChartItem1.Hint = "Show to what extent values have changed for different points in the same series.";
            chartControlCommandGalleryItemGroup3DLine1.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            createLine3DChartItem1,
            createFullStackedLine3DChartItem1,
            createSpline3DChartItem1,
            createStackedLine3DChartItem1,
            createStepLine3DChartItem1});
            this.commandBarGalleryDropDown2.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            chartControlCommandGalleryItemGroup2DLine1,
            chartControlCommandGalleryItemGroup3DLine1});
            this.commandBarGalleryDropDown2.Manager = this.barManager1;
            this.commandBarGalleryDropDown2.Name = "commandBarGalleryDropDown2";
            this.commandBarGalleryDropDown2.ShowNavigationHeader = DevExpress.Utils.DefaultBoolean.True;
            // 
            // commandBarGalleryDropDown3
            // 
            // 
            // 
            // 
            createPieChartItem1.Caption = "Pie";
            createPieChartItem1.Description = resources.GetString("createPieChartItem1.Description");
            createPieChartItem1.Hint = resources.GetString("createPieChartItem1.Hint");
            createDoughnutChartItem1.Caption = "Doughnut";
            createDoughnutChartItem1.Description = "Display the contribution of each value to a total like a pie chart, but it can co" +
    "ntain multiple series.";
            createDoughnutChartItem1.Hint = "Display the contribution of each value to a total like a pie chart, but it can co" +
    "ntain multiple series.";
            createNestedDoughnutChartItem1.Caption = "Nested Doughnut";
            createNestedDoughnutChartItem1.Description = "Display the contribution of each value to a total while comparing series with one" +
    " doughnut nested in another one.";
            createNestedDoughnutChartItem1.Hint = "Display the contribution of each value to a total while comparing series with one" +
    " doughnut nested in another one.";
            chartControlCommandGalleryItemGroup2DPie1.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            createPieChartItem1,
            createDoughnutChartItem1,
            createNestedDoughnutChartItem1});
            createPie3DChartItem1.Caption = "Pie in 3-D";
            createPie3DChartItem1.Description = "Display the contribution of each value to a total.";
            createPie3DChartItem1.Hint = "Display the contribution of each value to a total.";
            createDoughnut3DChartItem1.Caption = "Doughnut in 3-D";
            createDoughnut3DChartItem1.Description = "Compare the percentage values of different point arguments in the same series, an" +
    "d illustrate these values as easy to understand pie slices, but with a hole in i" +
    "ts center.";
            createDoughnut3DChartItem1.Hint = "Compare the percentage values of different point arguments in the same series, an" +
    "d illustrate these values as easy to understand pie slices, but with a hole in i" +
    "ts center.";
            chartControlCommandGalleryItemGroup3DPie1.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            createPie3DChartItem1,
            createDoughnut3DChartItem1});
            this.commandBarGalleryDropDown3.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            chartControlCommandGalleryItemGroup2DPie1,
            chartControlCommandGalleryItemGroup3DPie1});
            this.commandBarGalleryDropDown3.Manager = this.barManager1;
            this.commandBarGalleryDropDown3.Name = "commandBarGalleryDropDown3";
            this.commandBarGalleryDropDown3.ShowNavigationHeader = DevExpress.Utils.DefaultBoolean.True;
            // 
            // commandBarGalleryDropDown4
            // 
            // 
            // 
            // 
            createRotatedBarChartItem1.Caption = "Bar";
            createRotatedBarChartItem1.Description = "Insert a bar chart.\r\n\r\nBar charts are the best chart type for comparing multiple " +
    "values.\r\n    ";
            createRotatedBarChartItem1.Hint = "Insert a bar chart.\r\n\r\nBar charts are the best chart type for comparing multiple " +
    "values.\r\n    ";
            createRotatedFullStackedBarChartItem1.Caption = "100% Stacked Bar";
            createRotatedFullStackedBarChartItem1.Description = resources.GetString("createRotatedFullStackedBarChartItem1.Description");
            createRotatedFullStackedBarChartItem1.Hint = resources.GetString("createRotatedFullStackedBarChartItem1.Hint");
            createRotatedSideBySideFullStackedBarChartItem1.Caption = "Clustered 100% Stacked Bar";
            createRotatedSideBySideFullStackedBarChartItem1.Description = "Combine the advantages of both the 100% Stacked Bar and Clustered Bar chart types" +
    ", so you can stack different bars, and combine them into groups across the same " +
    "axis value.";
            createRotatedSideBySideFullStackedBarChartItem1.Hint = "Combine the advantages of both the 100% Stacked Bar and Clustered Bar chart types" +
    ", so you can stack different bars, and combine them into groups across the same " +
    "axis value.";
            createRotatedSideBySideStackedBarChartItem1.Caption = "Clustered Stacked Bar";
            createRotatedSideBySideStackedBarChartItem1.Description = "Combine the advantages of both the Stacked Bar and Clustered Bar chart types, so " +
    "that you can stack different bars, and combine them into groups across the same " +
    "axis value.";
            createRotatedSideBySideStackedBarChartItem1.Hint = "Combine the advantages of both the Stacked Bar and Clustered Bar chart types, so " +
    "that you can stack different bars, and combine them into groups across the same " +
    "axis value.";
            createRotatedStackedBarChartItem1.Caption = "Stacked Bar";
            createRotatedStackedBarChartItem1.Description = "Compare the contribution of each value to a total across categories by using hori" +
    "zontal rectangles.";
            createRotatedStackedBarChartItem1.Hint = "Compare the contribution of each value to a total across categories by using hori" +
    "zontal rectangles.";
            chartControlCommandGalleryItemGroup2DBar1.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            createRotatedBarChartItem1,
            createRotatedFullStackedBarChartItem1,
            createRotatedSideBySideFullStackedBarChartItem1,
            createRotatedSideBySideStackedBarChartItem1,
            createRotatedStackedBarChartItem1});
            this.commandBarGalleryDropDown4.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            chartControlCommandGalleryItemGroup2DBar1});
            this.commandBarGalleryDropDown4.Manager = this.barManager1;
            this.commandBarGalleryDropDown4.Name = "commandBarGalleryDropDown4";
            this.commandBarGalleryDropDown4.ShowNavigationHeader = DevExpress.Utils.DefaultBoolean.True;
            // 
            // commandBarGalleryDropDown5
            // 
            // 
            // 
            // 
            createAreaChartItem1.Caption = "Area";
            createAreaChartItem1.Description = "Insert an area chart.\r\n\r\nArea charts emphasize differences between several sets o" +
    "f data over a period of time.\r\n    ";
            createAreaChartItem1.Hint = "Insert an area chart.\r\n\r\nArea charts emphasize differences between several sets o" +
    "f data over a period of time.\r\n    ";
            createFullStackedAreaChartItem1.Caption = "100% Stacked Area";
            createFullStackedAreaChartItem1.Description = "Display the trend of the percentage each value contributes over time or categorie" +
    "s.\r\n\r\nUse it to emphasize the trend in the proportion of each series.\r\n    ";
            createFullStackedAreaChartItem1.Hint = "Display the trend of the percentage each value contributes over time or categorie" +
    "s.\r\n\r\nUse it to emphasize the trend in the proportion of each series.\r\n    ";
            createFullStackedSplineAreaChartItem1.Caption = "100% Stacked Spline Area";
            createFullStackedSplineAreaChartItem1.Description = "Behave similar to 100% Stacked Area, but plot a fitted curve through each data po" +
    "int in a series.";
            createFullStackedSplineAreaChartItem1.Hint = "Behave similar to 100% Stacked Area, but plot a fitted curve through each data po" +
    "int in a series.";
            createSplineAreaChartItem1.Caption = "Spline Area";
            createSplineAreaChartItem1.Description = "Behave similar to Area Chart but plot a fitted curve through each data point in a" +
    " series.";
            createSplineAreaChartItem1.Hint = "Behave similar to Area Chart but plot a fitted curve through each data point in a" +
    " series.";
            createStackedAreaChartItem1.Caption = "Stacked Area";
            createStackedAreaChartItem1.Description = "Display the trend of the contribution of each value over time or categories.\r\n\r\nU" +
    "se it to emphasize the trend in the total across series for one category.\r\n    ";
            createStackedAreaChartItem1.Hint = "Display the trend of the contribution of each value over time or categories.\r\n\r\nU" +
    "se it to emphasize the trend in the total across series for one category.\r\n    ";
            createStackedSplineAreaChartItem1.Caption = "Stacked Spline Area";
            createStackedSplineAreaChartItem1.Description = "Behave similar to Stacked Area Chart but plot a fitted curve through each data po" +
    "int in a series.";
            createStackedSplineAreaChartItem1.Hint = "Behave similar to Stacked Area Chart but plot a fitted curve through each data po" +
    "int in a series.";
            createStepAreaChartItem1.Caption = "Step Area";
            createStepAreaChartItem1.Description = "Show how much values have changed for different points of the same series.";
            createStepAreaChartItem1.Hint = "Show how much values have changed for different points of the same series.";
            chartControlCommandGalleryItemGroup2DArea1.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            createAreaChartItem1,
            createFullStackedAreaChartItem1,
            createFullStackedSplineAreaChartItem1,
            createSplineAreaChartItem1,
            createStackedAreaChartItem1,
            createStackedSplineAreaChartItem1,
            createStepAreaChartItem1});
            createArea3DChartItem1.Caption = "3-D Area";
            createArea3DChartItem1.Description = resources.GetString("createArea3DChartItem1.Description");
            createArea3DChartItem1.Hint = resources.GetString("createArea3DChartItem1.Hint");
            createFullStackedArea3DChartItem1.Caption = "100% Stacked Area in 3-D";
            createFullStackedArea3DChartItem1.Description = resources.GetString("createFullStackedArea3DChartItem1.Description");
            createFullStackedArea3DChartItem1.Hint = resources.GetString("createFullStackedArea3DChartItem1.Hint");
            createFullStackedSplineArea3DChartItem1.Caption = "100% Stacked Spline Area in 3-D";
            createFullStackedSplineArea3DChartItem1.Description = "Behave similar to 100% Stacked Area Chart in 3D, but plot a fitted curve through " +
    "each data point in a series.";
            createFullStackedSplineArea3DChartItem1.Hint = "Behave similar to 100% Stacked Area Chart in 3D, but plot a fitted curve through " +
    "each data point in a series.";
            createSplineArea3DChartItem1.Caption = "Spline Area in 3-D";
            createSplineArea3DChartItem1.Description = "Behave similar to 3D Area Chart, but plot a fitted curve through each data point " +
    "in a series.";
            createSplineArea3DChartItem1.Hint = "Behave similar to 3D Area Chart, but plot a fitted curve through each data point " +
    "in a series.";
            createStackedArea3DChartItem1.Caption = "Stacked Area in 3-D";
            createStackedArea3DChartItem1.Description = "Display series as areas on a diagram, so that the value of each data point is agg" +
    "regated with the underlying data points\' values.";
            createStackedArea3DChartItem1.Hint = "Display series as areas on a diagram, so that the value of each data point is agg" +
    "regated with the underlying data points\' values.";
            createStackedSplineArea3DChartItem1.Caption = "Stacked Spline Area in 3-D";
            createStackedSplineArea3DChartItem1.Description = "Behave similar to Stacked Area in 3D chart, but plot a fitted curve through each " +
    "data point in a series.";
            createStackedSplineArea3DChartItem1.Hint = "Behave similar to Stacked Area in 3D chart, but plot a fitted curve through each " +
    "data point in a series.";
            createStepArea3DChartItem1.Caption = "Step Area in 3-D";
            createStepArea3DChartItem1.Description = "Show to what extent values have changed for different points in the same series.";
            createStepArea3DChartItem1.Hint = "Show to what extent values have changed for different points in the same series.";
            chartControlCommandGalleryItemGroup3DArea1.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            createArea3DChartItem1,
            createFullStackedArea3DChartItem1,
            createFullStackedSplineArea3DChartItem1,
            createSplineArea3DChartItem1,
            createStackedArea3DChartItem1,
            createStackedSplineArea3DChartItem1,
            createStepArea3DChartItem1});
            this.commandBarGalleryDropDown5.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            chartControlCommandGalleryItemGroup2DArea1,
            chartControlCommandGalleryItemGroup3DArea1});
            this.commandBarGalleryDropDown5.Manager = this.barManager1;
            this.commandBarGalleryDropDown5.Name = "commandBarGalleryDropDown5";
            this.commandBarGalleryDropDown5.ShowNavigationHeader = DevExpress.Utils.DefaultBoolean.True;
            // 
            // commandBarGalleryDropDown6
            // 
            // 
            // 
            // 
            createPointChartItem1.Caption = "Point";
            createPointChartItem1.Description = "Use it when it\'s necessary to show stand-alone data points on the same chart plot" +
    ".";
            createPointChartItem1.Hint = "Use it when it\'s necessary to show stand-alone data points on the same chart plot" +
    ".";
            createBubbleChartItem1.Caption = "Bubble";
            createBubbleChartItem1.Description = "Resemble a Scatter chart, but compare sets of three values instead of two. The th" +
    "ird value determines the size of the bubble marker.";
            createBubbleChartItem1.Hint = "Resemble a Scatter chart, but compare sets of three values instead of two. The th" +
    "ird value determines the size of the bubble marker.";
            chartControlCommandGalleryItemGroupPoint1.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            createPointChartItem1,
            createBubbleChartItem1});
            createFunnelChartItem1.Caption = "Funnel";
            createFunnelChartItem1.Description = resources.GetString("createFunnelChartItem1.Description");
            createFunnelChartItem1.Hint = resources.GetString("createFunnelChartItem1.Hint");
            createFunnel3DChartItem1.Caption = "3-D Funnel";
            createFunnel3DChartItem1.Description = resources.GetString("createFunnel3DChartItem1.Description");
            createFunnel3DChartItem1.Hint = resources.GetString("createFunnel3DChartItem1.Hint");
            chartControlCommandGalleryItemGroupFunnel1.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            createFunnelChartItem1,
            createFunnel3DChartItem1});
            createStockChartItem1.Caption = "Stock";
            createStockChartItem1.Description = resources.GetString("createStockChartItem1.Description");
            createStockChartItem1.Hint = resources.GetString("createStockChartItem1.Hint");
            createCandleStickChartItem1.Caption = "Candle Stick";
            createCandleStickChartItem1.Description = resources.GetString("createCandleStickChartItem1.Description");
            createCandleStickChartItem1.Hint = resources.GetString("createCandleStickChartItem1.Hint");
            chartControlCommandGalleryItemGroupFinancial1.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            createStockChartItem1,
            createCandleStickChartItem1});
            createRadarPointChartItem1.Caption = "Radar Point";
            createRadarPointChartItem1.Description = "Show points from two or more different series on the same points arguments on a c" +
    "ircular grid that has multiple axes along which data can be plotted.";
            createRadarPointChartItem1.Hint = "Show points from two or more different series on the same points arguments on a c" +
    "ircular grid that has multiple axes along which data can be plotted.";
            createRadarLineChartItem1.Caption = "Radar Line";
            createRadarLineChartItem1.Description = "Show trends for several series and compare their values for the same points argum" +
    "ents on a circular grid that has multiple axes along which data can be plotted.";
            createRadarLineChartItem1.Hint = "Show trends for several series and compare their values for the same points argum" +
    "ents on a circular grid that has multiple axes along which data can be plotted.";
            createRadarAreaChartItem1.Caption = "Radar Area";
            createRadarAreaChartItem1.Description = "Display series as filled area on a circular grid that has multiple axes along whi" +
    "ch data can be plotted.";
            createRadarAreaChartItem1.Hint = "Display series as filled area on a circular grid that has multiple axes along whi" +
    "ch data can be plotted.";
            chartControlCommandGalleryItemGroupRadar1.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            createRadarPointChartItem1,
            createRadarLineChartItem1,
            createRadarAreaChartItem1});
            createPolarPointChartItem1.Caption = "Polar Point";
            createPolarPointChartItem1.Description = "Show points from two or more different series on the same circular diagram on the" +
    " basis of angles.";
            createPolarPointChartItem1.Hint = "Show points from two or more different series on the same circular diagram on the" +
    " basis of angles.";
            createPolarLineChartItem1.Caption = "Polar Line";
            createPolarLineChartItem1.Description = "Show trends for several series and compare their values for the same points argum" +
    "ents on a circular diagram on the basis of angles.";
            createPolarLineChartItem1.Hint = "Show trends for several series and compare their values for the same points argum" +
    "ents on a circular diagram on the basis of angles.";
            createPolarAreaChartItem1.Caption = "Polar Area";
            createPolarAreaChartItem1.Description = "Display series as filled area on a circular diagram on the basis of angles.";
            createPolarAreaChartItem1.Hint = "Display series as filled area on a circular diagram on the basis of angles.";
            chartControlCommandGalleryItemGroupPolar1.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            createPolarPointChartItem1,
            createPolarLineChartItem1,
            createPolarAreaChartItem1});
            createRangeBarChartItem1.Caption = "Range Column";
            createRangeBarChartItem1.Description = "Display vertical columns along the Y-axis (the axis of values). Each column repre" +
    "sents a range of data for each argument value.";
            createRangeBarChartItem1.Hint = "Display vertical columns along the Y-axis (the axis of values). Each column repre" +
    "sents a range of data for each argument value.";
            createSideBySideRangeBarChartItem1.Caption = "Clustered Range Column";
            createSideBySideRangeBarChartItem1.Description = "Show activity columns from different series grouped by their arguments. Each colu" +
    "mn represents a range of data with two values for each argument value.";
            createSideBySideRangeBarChartItem1.Hint = "Show activity columns from different series grouped by their arguments. Each colu" +
    "mn represents a range of data with two values for each argument value.";
            createRangeAreaChartItem1.Caption = "Range Area";
            createRangeAreaChartItem1.Description = "Display series as filled areas on a diagram, with two data points that define min" +
    "imum and maximum limits.\r\n\r\nUse it when you need to accentuate the delta between" +
    " start and end values.\r\n    ";
            createRangeAreaChartItem1.Hint = "Display series as filled areas on a diagram, with two data points that define min" +
    "imum and maximum limits.\r\n\r\nUse it when you need to accentuate the delta between" +
    " start and end values.\r\n    ";
            createRangeArea3DChartItem1.Caption = "Range Area in 3-D";
            createRangeArea3DChartItem1.Description = "Display series as filled areas on a diagram, with two data points that define min" +
    "imum and maximum limits.\r\n\r\nUse it when you need to accentuate the delta between" +
    " start and end values.\r\n    ";
            createRangeArea3DChartItem1.Hint = "Display series as filled areas on a diagram, with two data points that define min" +
    "imum and maximum limits.\r\n\r\nUse it when you need to accentuate the delta between" +
    " start and end values.\r\n    ";
            chartControlCommandGalleryItemGroupRange1.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            createRangeBarChartItem1,
            createSideBySideRangeBarChartItem1,
            createRangeAreaChartItem1,
            createRangeArea3DChartItem1});
            createGanttChartItem1.Caption = "Gantt";
            createGanttChartItem1.Description = "Track different activities during the time frame.";
            createGanttChartItem1.Hint = "Track different activities during the time frame.";
            createSideBySideGanttChartItem1.Caption = "Clustered Gantt";
            createSideBySideGanttChartItem1.Description = resources.GetString("createSideBySideGanttChartItem1.Description");
            createSideBySideGanttChartItem1.Hint = resources.GetString("createSideBySideGanttChartItem1.Hint");
            chartControlCommandGalleryItemGroupGantt1.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            createGanttChartItem1,
            createSideBySideGanttChartItem1});
            this.commandBarGalleryDropDown6.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            chartControlCommandGalleryItemGroupPoint1,
            chartControlCommandGalleryItemGroupFunnel1,
            chartControlCommandGalleryItemGroupFinancial1,
            chartControlCommandGalleryItemGroupRadar1,
            chartControlCommandGalleryItemGroupPolar1,
            chartControlCommandGalleryItemGroupRange1,
            chartControlCommandGalleryItemGroupGantt1});
            this.commandBarGalleryDropDown6.Manager = this.barManager1;
            this.commandBarGalleryDropDown6.Name = "commandBarGalleryDropDown6";
            this.commandBarGalleryDropDown6.ShowNavigationHeader = DevExpress.Utils.DefaultBoolean.True;
            // 
            // commandBarGalleryDropDown7
            // 
            this.commandBarGalleryDropDown7.Manager = this.barManager1;
            this.commandBarGalleryDropDown7.Name = "commandBarGalleryDropDown7";
            this.commandBarGalleryDropDown7.ShowNavigationHeader = DevExpress.Utils.DefaultBoolean.True;
            // 
            // commandBarGalleryDropDown8
            // 
            this.commandBarGalleryDropDown8.Manager = this.barManager1;
            this.commandBarGalleryDropDown8.Name = "commandBarGalleryDropDown8";
            this.commandBarGalleryDropDown8.ShowNavigationHeader = DevExpress.Utils.DefaultBoolean.True;
            // 
            // Sales
            // 
            this.Controls.Add(this.dataLayoutControl1);
            this.Controls.Add(this.barDockControlLeft);
            this.Controls.Add(this.barDockControlRight);
            this.Controls.Add(this.barDockControlBottom);
            this.Controls.Add(this.barDockControlTop);
            this.Name = "Sales";
            this.Size = new System.Drawing.Size(955, 554);
            ((System.ComponentModel.ISupportInitialize)(this.orderItemsGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.salesGridControl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.salesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.salesGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemProgressBar1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rangeControl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateTimeChartRangeControlClient1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataLayoutControl1)).EndInit();
            this.dataLayoutControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.popupMenu1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.barManager1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(doughnutSeriesLabel1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(doughnutSeriesView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(series1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(doughnutSeriesView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartControl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.salesSLI)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.buttonHide)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lcgChart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lcSales)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartControlLCI)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown8)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraLayout.SimpleLabelItem simpleLabelItem7;
        private DevExpress.XtraLayout.SimpleLabelItem simpleLabelItem4;
        private DevExpress.XtraLayout.SimpleLabelItem simpleLabelItem3;
        private DevExpress.XtraLayout.SimpleLabelItem simpleLabelItem2;
        private DevExpress.XtraLayout.SimpleLabelItem simpleLabelItem1;
        private DevExpress.XtraLayout.SimpleLabelItem  salesSLI;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem1;
        private DevExpress.XtraGrid.GridControl salesGridControl;
        private DevExpress.XtraGrid.Views.Grid.GridView salesGridView;
        private DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox repositoryItemComboBox1;
        private DevExpress.XtraEditors.Repository.RepositoryItemProgressBar repositoryItemProgressBar1;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup1;
        private System.Windows.Forms.BindingSource salesBindingSource;
        private DevExpress.XtraLayout.SimpleLabelItem simpleLabelItem5;
        private DevExpress.XtraDataLayout.DataLayoutControl dataLayoutControl1;
        private DevExpress.XtraLayout.SimpleLabelItem buttonHide;
        private DevExpress.XtraEditors.TileItem tileItemHighPriority;
        private DevExpress.XtraEditors.TileItem tileItemUrgent;
        private DevExpress.XtraEditors.TileItem tileItemCompleted;
        private DevExpress.XtraEditors.TileItem tileItemDeferred;
        private DevExpress.XtraEditors.TileItem tileItemNotStartedTask;
        private DevExpress.XtraEditors.TileItem tileItemInProgress;
        private DevExpress.XtraEditors.TileItem tileItemAll;
        private DevExpress.XtraGrid.Columns.GridColumn colInvoiceNumber;
        private DevExpress.XtraGrid.Columns.GridColumn colCustomer;
        private DevExpress.XtraGrid.Columns.GridColumn colStore;
        private DevExpress.XtraGrid.Columns.GridColumn colOrderDate;
        private DevExpress.XtraGrid.Columns.GridColumn colTotalAmount;
        private DevExpress.XtraLayout.LayoutControlItem chartControlLCI;
        private DevExpress.XtraCharts.ChartControl chartControl;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem;
        private DevExpress.XtraGrid.Views.Grid.GridView orderItemsGridView;
        private DevExpress.XtraGrid.Columns.GridColumn ProductGC;
        private DevExpress.XtraGrid.Columns.GridColumn unitsGridColumn;
        private DevExpress.XtraGrid.Columns.GridColumn totalGridColumn;
        private DevExpress.XtraGrid.Columns.GridColumn unitPriceGridColumn;
        private DevExpress.XtraGrid.Columns.GridColumn discountGridColumn;
        private DevExpress.XtraBars.Commands.CommandBarGalleryDropDown commandBarGalleryDropDown1;
        private DevExpress.XtraBars.Commands.CommandBarGalleryDropDown commandBarGalleryDropDown2;
        private DevExpress.XtraBars.Commands.CommandBarGalleryDropDown commandBarGalleryDropDown3;
        private DevExpress.XtraBars.Commands.CommandBarGalleryDropDown commandBarGalleryDropDown4;
        private DevExpress.XtraBars.Commands.CommandBarGalleryDropDown commandBarGalleryDropDown5;
        private DevExpress.XtraBars.Commands.CommandBarGalleryDropDown commandBarGalleryDropDown6;
        private DevExpress.XtraBars.Commands.CommandBarGalleryDropDown commandBarGalleryDropDown7;
        private DevExpress.XtraBars.Commands.CommandBarGalleryDropDown commandBarGalleryDropDown8;
        private DevExpress.XtraEditors.RangeControl rangeControl;
        private DevExpress.XtraEditors.DateTimeChartRangeControlClient dateTimeChartRangeControlClient1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem2;
        private DevExpress.XtraEditors.DropDownButton dropDownButton1;
        private DevExpress.XtraLayout.LayoutControlItem lcSales;
        private DevExpress.XtraBars.Ribbon.GalleryDropDown popupMenu1;
        private DevExpress.XtraBars.BarManager barManager1;
        private DevExpress.XtraBars.BarDockControl barDockControlTop;
        private DevExpress.XtraBars.BarDockControl barDockControlBottom;
        private DevExpress.XtraBars.BarDockControl barDockControlLeft;
        private DevExpress.XtraBars.BarDockControl barDockControlRight;
        private DevExpress.XtraBars.BarButtonItem barButtonItemContacts;
        private DevExpress.XtraBars.BarButtonItem barButtonItemStores;
        private DevExpress.XtraLayout.LayoutControlGroup lcgChart;

    }
}
